require 'chef/mixin/shell_out'
include Chef::Mixin::ShellOut

# Module to get Orcclient configuration parameters
module EnableCm
  # Function to check the whether chefclient enable in chkconfig
  def self.check_enable
    check_enable = shell_out('chkconfig --list | grep orcclient -q -s ;echo $?')
    return check_enable.stdout.chomp
  end

  # Function to check the check config on or off for runlevels
  def self.check_chkconfig
    out2 = []
    out3 = []
    out = shell_out("chkconfig --list | grep orcclient |awk '{print $2,$3,$4,$5,$6,$7,$8}'")
    out1 = out.stdout.split('\n')
    out1.each do |i|
      a = i.split(' ')
      out2 << a
    end
    str = out2.join(' ')
    out2 = str.split(' ')
    out2.each do |i|
      b = i.split(':')
      out3 << b
    end
    return out3
  end
end
