vmdetails = GeneralLibs::VmFunctions.vminfo(node)
region = vmdetails[1]
if GeneralLibs::VmFunctions.conf_name != 'none'
  default['enable-cm']['envconfig'] = GeneralLibs::VmFunctions.conf_name
elsif GeneralLibs::VmFunctions.role_name != 'none'
  default['enable-cm']['envconfig'] = GeneralLibs::VmFunctions.role_name
else
  default['enable-cm']['envconfig'] = GeneralLibs::VmFunctions.envconfig_name
end
if GeneralLibs::VmFunctions.envconfig_name == 'GITCOMPUTE'
  if GeneralLibs::VmFunctions.appinfo['AppID'].to_i  == 427 || GeneralLibs::VmFunctions.appinfo['AppID'].to_i  == 851 
    default['enable-cm']['run_time'] = 86400
  else 
    if region == 'iad'
      default['enable-cm']['run_time'] = 5400
    else
      default['enable-cm']['run_time'] = 3600
    end
  end
else
  default['enable-cm']['run_time'] = 43200
end
if File.exist?('/opt/orc/bin/orc-client')
  default['enable-cm']['chef-client'] = '/opt/orc/bin/orc-client'
  default['enable-cm']['chef-serv'] = 'orc-client'
else
  default['enable-cm']['chef-client'] = '/usr/bin/chef-client'
  default['enable-cm']['chef-serv'] = 'chef-client'
end
default['enable-cm']['daemon'] = "#{node['enable-cm']['envconfig']}_CONFIG_CB.json"
default['enable-cm']['client'] = '/root/.client.rb'
default['enable-cm']['log'] = '/root/.orcclient_overlay.log'
default['enable-cm']['env'] = GeneralLibs::VmFunctions.environment
