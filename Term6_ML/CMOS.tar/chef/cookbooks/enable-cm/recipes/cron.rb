#
# Cookbook Name:: enable-cm
# Recipe:: cron
#
# Copyright 2021, ORACLE
# Author:: naga.sai.vosetti@oracle.com
# All rights reserved - Do Not Redistribute
#
   
#############################################################
## Enable cron configuration cookbook for  Oracle Linux    ##
#############################################################

if node['platform'] == 'oracle' && node['platform_version'].to_i >= 6
  template '/usr/bin/config.sh' do
    source 'start.erb'
    owner 'root'
    group 'root'
    mode '0755'
    action :create
  end
  if GeneralLibs::VmFunctions.envconfig_name != 'GITCOMPUTE'
    cron_d 'enable_configuration' do
      action :create
      minute rand(59)
      hour rand(6)
      user 'root'
      command '/usr/bin/config.sh'
      not_if { ::File.exist?('/etc/cron.d/enable_configuration') }
    end
  else
    cron_d 'enable_configuration' do
      action :create
      minute rand(59)
      hour '*'
      user 'root'
      command '/usr/bin/config.sh'
      not_if { ::File.exist?('/etc/cron.d/enable_configuration') }
    end
  end
else
  template '/usr/bin/config.sh' do
    source 'start.erb'
    owner 'root'
    group 'root'
    mode '0755'
    action :create
  end
  cron 'enable_configuration' do
    action :create
    minute rand(59)
    hour rand(6)
    user 'root'
    command '/usr/bin/config.sh'
    only_if { shell_out("crontab -l | grep config.sh").exitstatus != 0 }
  end
end
