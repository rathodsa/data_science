#
# Cookbook Name:: enable-cm
# Recipe:: bootstrap
#
# Copyright 2021, ORACLE
# Author:: naga.sai.vosetti@oracle.com
# All rights reserved - Do Not Redistribute
#
########################################################
## Global Variables and dependent recipes declaration ##
########################################################
os_version = node['platform_version'].to_i

if GeneralLibs::VmFunctions.conf_name != 'none'
  role_name = GeneralLibs::VmFunctions.conf_name
elsif GeneralLibs::VmFunctions.role_name != 'none'
  role_name = GeneralLibs::VmFunctions.role_name
else
  role_name = GeneralLibs::VmFunctions.envconfig_name
end
   

###################################################################
## Enable configuration cookbook for first boot  Oracle Linux    ##
###################################################################

if node['platform'] == 'oracle'
  file '/etc/rc.d/rc.local' do
    mode '0755'
    owner 'root'
    group 'root'
  end
  execute 'rc.local enable and start' do
    command 'sed -i "1 s/^/#!\/bin\/bash\n/" /etc/rc.d/rc.local'
    only_if { `head -n 1 /etc/rc.d/rc.local |grep bin |egrep 'bash|sh' > /dev/null;echo $?`.to_i != 0 }
  end
  ruby_block 'Adding one time bootup to rc.local'  do
    block do
      file = Chef::Util::FileEdit.new('/etc/rc.d/rc.local')
      file.insert_line_if_no_match('^cd /var/chef', "cd /var/chef;#{node['enable-cm']['chef-client']} -c /root/.client.rb -z  -j roles/#{role_name}_CONFIG_CB.json --local-mode | tee -a /root/.stinstall.log;if [[ #{os_version} -eq 7 ]] || [[ #{os_version} -gt 7 ]];then systemctl disable rc-local;fi;sed -i '/orc-client/d' /etc/rc.d/rc.local;sed -i '/chef-client/d' /etc/rc.d/rc.local")
      file.write_file
    end
    only_if { `grep #{node['enable-cm']['chef-client']} /etc/rc.d/rc.local |wc -l`.to_i == 0 }
  end
  service 'rc-local' do
    action :enable
    only_if { node['platform_version'].to_i >= 7 }
  end
end
