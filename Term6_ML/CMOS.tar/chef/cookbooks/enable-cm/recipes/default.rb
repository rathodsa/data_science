#
# Cookbook Name:: enable-cm
# Recipe:: default
#
# Copyright 2021, ORACLE
# Author:: naga.sai.vosetti@oracle.com
# All rights reserved - Do Not Redistribute
#
# Include recipes
include_recipe 'enable-cm::cron'
include_recipe 'enable-cm::bootstrap'
include_recipe 'enable-cm::orcclient'
