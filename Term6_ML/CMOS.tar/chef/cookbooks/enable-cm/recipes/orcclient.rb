#
# Cookbook Name:: orcclient
# Recipe:: default
#
# Copyright 2017, ORACLE
# Author:: naga.sai.vosetti@oracle.com
# All rights reserved - Do Not Redistribute
#
########################################################
## Global Variables and dependent recipes declaration ##
########################################################
enablecm_hash = Hash[EnableCm.check_chkconfig.map { |key, value| [key, value] }]

################################################################
## Orc client to run as service cookbook for Oracle Linux    ##
################################################################

if node['platform'] == 'oracle'
  ############################################
  ## service configuration for OS below OL7 ##
  ############################################
  if node['platform_version'][0].to_i < 7
    template '/etc/init.d/orcclient' do
      source 'orcclient.erb'
      owner 'root'
      group 'root'
      mode '0755'
      action :create
      notifies :restart, 'service[orcclient]', :delayed
    end
    bash 'enabling and checking configuration' do
      code <<-EOH
	chkconfig --add orcclient
        chkconfig orcclient on
        EOH
      not_if { EnableCm.check_enable.to_i.zero? }
    end
    service 'orcclient' do
      action [:disable]
      supports start: true, restart: true, status: true
    end
    if enablecm_hash.empty?
      Chef::Log.info('Chkconfig is not configured for orcclient')
    else
      enablecm_hash.each do |key, value|
        if key.to_s == '3' && value.to_s != 'on'
          system('chkconfig --level 3 orcclient off')
        end
        if key.to_s == '4' && value.to_s != 'on'
          system('chkconfig --level 4 orcclient off')
        end
        if key.to_s == '5' && value.to_s != 'on'
          system('chkconfig --level 5 orcclient off')
        end
      end
    end
  else
    ################################################
    ## service configuration for OS OL7 and above ##
    ################################################
    template '/etc/systemd/system/orcclient.service' do
      source 'orcclientservice.erb'
      owner 'root'
      group 'root'
      mode '0644'
      action :create
      notifies :run, 'execute[daemon-reload]', :immediately
      notifies :restart, 'service[orcclient.service]', :delayed
    end
    execute 'daemon-reload' do
      command 'systemctl daemon-reload'
      action :nothing
    end
    service 'orcclient.service' do
      action [:disable]
      supports start: true, restart: true, status: true
    end
  end
  ############################################
  ## File for rotation of log configuration ##
  ############################################
  cookbook_file '/etc/logrotate.d/orcclient' do
    source 'orcclient'
    owner 'root'
    group 'root'
    mode '0644'
    action :create
  end
else
  Chef::Log.info('Unsupported OS')
end
