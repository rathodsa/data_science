name             'enable-cm'
maintainer       'ORACLE'
maintainer_email 'naga.sai.vosetti@oracle.com'
license          'All rights reserved'
description      'Installs/Configures enable-cm'
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          '0.1.0'
depends 'General_Lib_Functions'
