# Author  jagannadham.mahanti@oracle.com
require 'open-uri'
require 'socket'
require 'net/http'
require 'time'

module GeneralLibs
  # Class inside the module to get required information for other cookbooks
  class VmFunctions
    # Function to return current machine is cloud or noncloup based on below url
    def self.check_cloudvm_or_not
      url = URI.parse('http://169.254.169.254/latest/meta-data/local-ipv4')
      http = Net::HTTP.new(url.host, url.port)
      http.read_timeout = 20
      http.open_timeout = 20
      begin
        resp = http.start { |http| http.get(url.path) }
        @response_cloud = resp.kind_of? Net::HTTPResponse
        @response = 'CLOUD' if @response_cloud
      rescue Timeout::Error, Errno::EHOSTUNREACH, StandardError, Errno::ETIMEDOUT, OpenURI::HTTPError, Errno::ECONNRESET, EOFError, SocketError
        @response = 'NONCLOUD'
      end
      return @response
    end

    # Function to return IPADDRESS FQDN HOSTNAME details
    def self.cloud_ip()
        @oci_check = self.check_oci_or_not
        if @oci_check == 'OCI'
          @response = Mixlib::ShellOut.new('curl --connect-timeout 20 -H "Authorization: Bearer Oracle" -L http://169.254.169.254/opc/v2/vnics/0/privateIp')
          @response.run_command
          @ip_address = @response.stdout.to_s
        else 
          @response = Mixlib::ShellOut.new('curl --connect-timeout 20 -L http://169.254.169.254/latest/meta-data/public-ipv4') 
          @response.run_command 
          if @response.stdout.to_s.empty?
             @response = Mixlib::ShellOut.new('curl --connect-timeout 20 -L http://169.254.169.254/latest/meta-data/local-ipv4')
             @response.run_command
          end
          @ip_address = @response.stdout.to_s
        end

        begin
          if @ip_address.include? "404 Not Found"
            raise "NOT CLOUD BAREMETAL HOST"
          end
        rescue Timeout::Error, Errno::EHOSTUNREACH, StandardError, Errno::ETIMEDOUT, OpenURI::HTTPError, Errno::ECONNRESET, EOFError, SocketError, HTTPNotFound
          @ip_address = ''
        end
     
        if @ip_address.empty?
          uri = URI.parse('http://169.254.169.254/latest/meta-data/local-ipv4')
          begin
            @response = Net::HTTP.get_response(uri)
            @ip_address = @response.body
            if @ip_address.include? "404 Not Found"
              raise "NOT CLOUD BAREMETAL HOST"
            end
          rescue Timeout::Error, Errno::EHOSTUNREACH, StandardError, Errno::ETIMEDOUT, OpenURI::HTTPError, Errno::ECONNRESET, EOFError, SocketError, HTTPNotFound
            @ip_address = ''
          end
        end
        return @ip_address
    end

    # Function to return IPADDRESS FQDN HOSTNAME details
    def self.dnslookup(node)
      @vm_type_dns = self.check_cloudvm_or_not
      if @vm_type_dns == 'CLOUD'
        @glib_ipaddr = self.cloud_ip
        if @glib_ipaddr.empty?
          @glib_nodename = `/usr/bin/host #{node['ipaddress']} | awk '{print $NF}'| awk -F"." '{print $1}'`.chomp
          @FQDN1=`/usr/bin/host #{node['ipaddress']} | awk '{print $NF}'`.chomp
          @glib_ipaddr = node['ipaddress']
        else
          @FQDN1 = `/usr/bin/host #{@glib_ipaddr} | awk '{print $NF}'`.chomp
        end
        #@FQDN1 = `/usr/bin/host #{@glib_ipaddr} | awk '{print $NF}'`.chomp
        @glib_fqdn="#{@FQDN1}".chomp('.')
        @glib_nodename = @glib_fqdn.split('.')[0]
      else
        @glib_nodename = `/usr/bin/host #{node['ipaddress']} | awk '{print $NF}'| awk -F"." '{print $1}'`.chomp
        @FQDN1 = `/usr/bin/host #{node['ipaddress']} | awk '{print $NF}'`.chomp
        @glib_fqdn="#{@FQDN1}".chomp('.')
        @glib_ipaddr = node['ipaddress']
      end
      return @glib_ipaddr, @glib_nodename, @glib_fqdn
    end

    # Function to return HOSTNAME if you pass ipaddress
    def self.vmname(ipaddress)
      ext_ip = ipaddress
      @host_name = Resolv.getname("#{ext_ip}")
      return @host_name
    end

    # Function to  return IPADDRESS if you pass hostname
    def self.ipaddress(vmname)
      @vmname_ip = vmname
      ipaddr = Socket.getaddrinfo("#{@vmname_ip}", Socket::AF_INET)[0][3]
      return ipaddr
    end

    # Function to check json file exist or not
    def self.vminfo_json_avail(node)
      begin
        @info2 = Hash[*File.read('/root/.devops.json').split(/[=\n]/)]
      rescue ArgumentError
      #rescue => e
        @vmname_api = node['hostname']
        url = "http://devops.oraclecorp.com/host/api/#{@vmname_api}/data"
        puts 'CREATING LOCAL DEVOPS JSON FILE AS OLD FILE IS MODIFIED OR CORRUPTED'
        begin
          @info = URI.parse(url).read.split("\n")
        rescue => e
          return self.vminfo_json_not_avail(node)
        end
        File.open('/root/.devops.json', 'w+') do |f|
          @info.each { |element| f.puts(element) }
        end
      end
      @info2 = Hash[*File.read('/root/.devops.json').split(/[=\n]/)]
      return @info2
    end

    # Creating devops json file if not EXISTS
    def self.vminfo_json_not_avail(node)
      begin
        @vmname_api_not = node['hostname']
        url = "http://devops.oraclecorp.com/host/api/#{@vmname_api_not}/data"
        @info = URI.parse(url).read.split("\n")
        puts 'CREATING LOCAL DEVOPS JSON FILE ..........'
        File.open('/root/.devops.json', 'w+') do |f|
          @info.each { |element| f.puts(element) }
        end
        @info1 = Hash[@info.map { |el| el.split '=' }]
        return @info1
      rescue => e
         begin
         puts "DEVOPS API IS NOT LOADING FOR THIS HOST,SO GETTING REGION NAME...................."
         @vminfo_cloud_baremetal = Mixlib::ShellOut.new('curl --connect-timeout 20 -H "Authorization: Bearer Oracle" -L http://169.254.169.254/opc/v2/instance/region')
         @vminfo_cloud_baremetal.run_command
         @region=@vminfo_cloud_baremetal.stdout.to_s
         @region = 'lhr' if @region == 'uk-london-1'
         @region = 'bom' if @region == 'ap-mumbai-1'

         #@region = @vmname_api_not if @region.nil? || @region.empty?
         if (@region.include? "404 Not Found") || @region.nil? || @region.empty?
           raise "NOT CLOUD BAREMETAL HOST"
         end
         rescue =>e
          puts "DEVOPS API IS NOT RESPONDING OR REQUEST IS NOT GOING OUTSIDE BECAUSE OF #{e},SO TAKING REGION NAME FROM HOSTNAME"
          @region = self.check_colo(node)
          if @region.nil? || @region.empty?          
            @region = @vmname_api_not
            @region = @region[0,3]
            @region = 'dnv' if @region == 'den'
            @region = 'nedc' if @region == 'nsh'
            @region = 'adc' if @region == 'arp'
            @region = 'adc' if @region == 'brm'
            @region = 'lhr' if @region == 'uk-london-1'
            @region = 'bom' if @region == 'ap-mumbai-1'
          end
        end       
        File.open('/root/.devops.json', 'w+') do |f|
          f.write(f.puts "region_sgd_name=" + @region)
        end
         @info1 = Hash[*File.read('/root/.devops.json').split(/[=\n]/)]
         return @info1
      end
    end

    # Function to check OCI instance or not
    def self.check_oci_or_not
      @vminfo_oci = Mixlib::ShellOut.new('curl -L --connect-timeout 20 -H "Authorization: Bearer Oracle" -L http://169.254.169.254/opc/v2/instance')
      @vminfo_oci.run_command
      @oci_status=@vminfo_oci.stdout
      # @oci_response = 'OCI' if (@oci_status && !@oci_status.nil? && !@oci_status.empty?)
      @oci_response = 'OCI' if !(@oci_status.include? "404 Not Found") && @oci_status && !@oci_status.nil? && !@oci_status.empty?
      return @oci_response
    end

    # Function to return LOB,REGION,STORAGE FILER and ADE_SITENAME etc.. Details
    # using below Devops API And also creating devops json file locally to store
    # devops information inorder to avoid to hit the devops API multiple times
    def self.vminfo(node)
      if File.exist?('/root/.devops.json') && (Time.now.to_i - File.stat('/root/.devops.json').ctime.to_i) / (60 * 60) < 24 && File.foreach('/root/.devops.json').count > 0 && File.readlines("/root/.devops.json").grep(/region_sgd_name=./).size > 0
        @info = self.vminfo_json_avail(node)
      else
        @info = self.vminfo_json_not_avail(node)
      end
      begin
        isoci = self.check_oci_or_not()
        lob = @info['service_area']
        region = @info['region_sgd_name']
        region = 'slc' if region == 'ucf'
        region = 'idc' if region == 'blr'
        region = 'adc' if region == 'arp'
        region = 'adc' if region == 'brm'
        if region == 'None' || (region.include? "none") || isoci == "OCI"
          @region_oci = Mixlib::ShellOut.new('curl -L --connect-timeout 20 -H "Authorization: Bearer Oracle" -L http://169.254.169.254/opc/v2/instance/region')
          @region_oci.run_command
          region = @region_oci.stdout.to_s
          region = 'lhr' if region == 'uk-london-1'
          region = 'bom' if region == 'ap-mumbai-1'
        end
        storage = node['General_Lib_Functions']["#{region}"]
        ade_sitename = node['General_Lib_Functions_ade_site']["#{region}"]
        devops_managed = @info['managed']
        devops_reservation_status = @info['reservation_status']
        devops_user_short = @info['user_short']
        devops_reserved_until = @info['reserved_until']
        devops_reservation_type = @info['reservation_type']
        devops_use = @info['use']
        devops_decommission_date = @info['decommission_date']
        devops_subnet = @info['subnet']
      rescue NoMethodError
        puts 'DEVOPS JSON FILE CORRUPTED,DELETE THIS /root/.devops.json AND RUN THE JOB AGAIN'
      end
      return lob, region, storage, ade_sitename, devops_managed, devops_reservation_status, devops_user_short, devops_reserved_until, devops_reservation_type, devops_use, devops_decommission_date, devops_subnet
    end

    # Function to return IPADDRESS GATEWAY details
    def self.networkinfo(node)
      node = node
      # @vmname=node['hostname']
      # ipaddr=Socket::getaddrinfo("#{@vmname}",Socket::AF_INET)[0][3]
      ipaddr_network = node['ipaddress']
      gateway_network = node['network']['default_gateway']
      return ipaddr_network, gateway_network
    end

    # Function to return Given host is VM or SERVER
    def self.vm_or_physical
      @vmtype_server = GeneralLibs::VmFunctions.check_cloudvm_or_not
      if @vmtype_server == 'NONCLOUD'
        find = Mixlib::ShellOut.new("/usr/sbin/dmidecode -s system-product-name |egrep -v 'HVM|domU' | egrep -i 'sun|oracle|Fujitsu|ibm|ProLiant|PowerEdge' ")
        find.run_command
        @status = find.stdout
        return @status == '' ? 'VM' : 'SERVER'
      else
        return @vmtype_server
      end
    end
    
    #Port Status Check using socket
    def self.port_check?(ip, port)
       begin
         starting = Process.clock_gettime(Process::CLOCK_MONOTONIC)
         s = Socket.tcp(ip, port, connect_timeout: 5)
	 ending = Process.clock_gettime(Process::CLOCK_MONOTONIC)
	 elapsed = ending - starting
         s.close
         return elapsed 
       rescue => e
         # possible exceptions:
         # - Errno::ECONNREFUSED
         # - Errno::EHOSTUNREACH
         # - Errno::ETIMEDOUT
         return 'false'
       end
    end 

    # Function to return nearest yum repo server
    def self.nearest_yum
      @hippa_yum = self.hippadetails
      if @hippa_yum == 'hippa'
        return 'http://hsgbuhsz-yum-1.sniadprinf1.hsgbuhsz01iad.oraclevcn.com'
      end

      arr_filer = ["pd-yum-adc-01.us.oracle.com","pd-yum-bur-01.us.oracle.com","pd-yum-bus-01.us.oracle.com","pd-yum-sca-01.us.oracle.com","pd-yum-slc-01.us.oracle.com","pd-yum-rws-01.us.oracle.com","pd-yum-den-01.us.oracle.com","lb-yum-bom.appoci.oraclecorp.com","lb-yum-lhr.appoci.oraclecorp.com","lb-yum-phx.appoci.oraclecorp.com","lb-yum-iad.appoci.oraclecorp.com"]
      ha_filer = {}
      for i in arr_filer do
        a_filer = self.port_check?(i,80)
        if a_filer == "false"
          a_filer = self.port_check?(i,443)
          if a_filer != "false"
            ha_filer['https://'+i] = a_filer
          end
        else
          ha_filer['http://'+i] = a_filer
        end
      end
      return ha_filer.sort_by { |key, value| value }.first[0]
    end

    # Function to check Hippa host
    def self.hippadetails
       if File.exist?('/root/.hippa')
         @host = 'hippa'
       end
      return @host
    end

    # Function to check CDC Host
    def self.cdc(node)
      if node['cde_gateway'].include?(node['network']['default_gateway'])
        @cdc_host = 'True'
      else
        @cdc_host = 'False'
      end
      return @cdc_host
    end

    # Function to check Colo Host
    def self.check_colo(node)
      netmask_num = `ip addr show #{node['network']['default_interface']} | grep -w inet | awk '{print $2}' | cut -d\/ -f2`.to_s.chomp.to_i
      colo = ['10.218.16.0/23', '10.218.18.0/23', '10.218.20.0/24', '10.218.1.0/27', '10.218.0.128/26', '10.218.32.0/22', '10.218.7.64/27', '10.218.36.0/23', '10.218.38.0/23', '10.218.0.192/26', '10.218.0.128/26', '10.218.0.64/27', '10.218.0.96/27', '10.218.2.0/25', '10.218.3.0/25', '10.218.3.128/25', '10.218.0.0/28', '10.218.0.16/29', '10.218.4.0/25', '10.218.4.128/25', '10.218.24.0/22', '10.218.28.0/22', '10.218.30.0/23', '10.218.8.0/23', '10.218.10.0/23', '10.218.12.0/23', '10.218.16.0/23', '10.218.18.0/23', '10.218.20.0/23', '10.218.32.0/22', '10.218.36.0/23', '10.218.38.0/23', '10.218.5.0/25', '10.138.208.0/23', '10.138.210.0/23', '10.138.212.0/23', '10.138.214.0/24', '10.138.215.0/24', '10.218.128.128/26']
      ip = IPAddress "#{node['ipaddress']}/#{netmask_num}"
      if colo.include?(ip.network.to_string)
        return "colo"
      end
      colo_dr = ['10.218.131.0/25', '10.218.164.0/23', '10.218.156.0/23', '10.218.129.0/27', '10.218.128.192/26', '10.138.228.0/23', '10.218.172.0/23', '10.218.138.0/23']
      if colo_dr.include?(ip.network.to_string)
        return "colo_dr"
      end
     end
    
   # Function to find Linux Release information
   def self.rel_num
     rel_info = Mixlib::ShellOut.new("grep -iw version /etc/os-release |cut -d. -f2")
     rel_info.run_command
     rel_i = rel_info.stdout.split('"')
     return rel_i[0].chomp
   end

   def self.tenancy_name
     if ( File.exist?('/var/lib/cloud/instance/user-data.txt.i') || File.exist?('/var/lib/cloud/instance/user-data.txt') || File.exist?('/root/.client.rb'))
       tenancy_chk1 = Mixlib::ShellOut.new(" grep -i ^infra_tenancy /var/lib/cloud/instance/user-data.txt.i|awk -F'=' '{print $2}'")
       tenancy_chk1.run_command
       @tenancy_name1 = tenancy_chk1.stdout.chomp.gsub(/\s|"|'/, '')
       if @tenancy_name1.empty?
         tenancy_chk2 = Mixlib::ShellOut.new(" grep -i ^infra_tenancy /var/lib/cloud/instance/user-data.txt|awk -F'=' '{print $2}'")
         tenancy_chk2.run_command
         @tenancy_name2 = tenancy_chk2.stdout.chomp.gsub(/\s|"|'/, '')
         if @tenancy_name2.empty?
           tenancy_chk3 = Mixlib::ShellOut.new(" grep -i ^infra_tenancy /root/.client.rb|awk -F'=' '{print $2}'")
           tenancy_chk3.run_command
           @tenancy_name3 = tenancy_chk3.stdout.chomp.gsub(/\s|"|'/, '')
           if @tenancy_name3.empty?
             @tenancy_name3 = 'none'
           end
           return @tenancy_name3.downcase
         else
           return @tenancy_name2.downcase
         end
       else
         return @tenancy_name1.downcase
       end
     else
       return 'none'
     end
   end

   def self.netgroup_details
     if ( File.exist?('/var/lib/cloud/instance/user-data.txt.i') || File.exist?('/var/lib/cloud/instance/user-data.txt') )
       netgroup_chk1 = Mixlib::ShellOut.new(" grep -i ^infra_netgroup /var/lib/cloud/instance/user-data.txt.i|awk -F'=' '{print $2}'")
       netgroup_chk1.run_command
       @netgroup_details1 = netgroup_chk1.stdout.chomp.gsub(/\s|"|'/, '')
       if @netgroup_details1.empty?
         netgroup_chk2 = Mixlib::ShellOut.new(" grep -i ^infra_netgroup /var/lib/cloud/instance/user-data.txt|awk -F'=' '{print $2}'")
         netgroup_chk2.run_command
         @netgroup_details2 = netgroup_chk2.stdout.chomp.gsub(/\s|"|'/, '')
         if @netgroup_details2.empty?
           @netgroup_details2 = 'none'
         end
         return @netgroup_details2.downcase
       else 
         return @netgroup_details1.downcase
       end
     else
       return 'none'
     end
   end

   def self.applob_details
     if ( File.exist?('/var/lib/cloud/instance/user-data.txt.i') || File.exist?('/var/lib/cloud/instance/user-data.txt') )
       applob_chk1 = Mixlib::ShellOut.new(" grep -i ^infra_applob /var/lib/cloud/instance/user-data.txt.i|awk -F'=' '{print $2}'")
       applob_chk1.run_command
       @applob_details1 = applob_chk1.stdout.chomp.gsub(/\s|"|'/, '')
       if @applob_details1.empty?
         applob_chk2 = Mixlib::ShellOut.new(" grep -i ^infra_applob /var/lib/cloud/instance/user-data.txt|awk -F'=' '{print $2}'")
         applob_chk2.run_command
         @applob_details2 = applob_chk2.stdout.chomp.gsub(/\s|"|'/, '')
         if @applob_details2.empty?
           @applob_details2 = 'none'
         end
         return @applob_details2
       else 
         return @applob_details1
       end
     else
       return 'none'
     end
   end

   def self.emdslob_details
     if ( File.exist?('/var/lib/cloud/instance/user-data.txt.i') || File.exist?('/var/lib/cloud/instance/user-data.txt') )
       emdslob_chk1 = Mixlib::ShellOut.new(" grep -i ^infra_emdslob /var/lib/cloud/instance/user-data.txt.i|awk -F'=' '{print $2}'")
       emdslob_chk1.run_command
       @emdslob_details1 = emdslob_chk1.stdout.chomp.gsub(/\s|"|'/, '')
       if @emdslob_details1.empty?
         emdslob_chk2 = Mixlib::ShellOut.new(" grep -i ^infra_emdslob /var/lib/cloud/instance/user-data.txt|awk -F'=' '{print $2}'")
         emdslob_chk2.run_command
         @emdslob_details2 = emdslob_chk2.stdout.chomp.gsub(/\s|"|'/, '')
         if @emdslob_details2.empty? 
           @emdslob_details2 = 'none'
         end
         return @emdslob_details2
       else
         return @emdslob_details1
       end
     else
       return 'none'
     end
   end

   def self.envconfig_name
     if ( File.exist?('/var/lib/cloud/instance/user-data.txt.i') || File.exist?('/var/lib/cloud/instance/user-data.txt') || File.exist?('/root/.client.rb') )
       envconfig_chk1 = Mixlib::ShellOut.new(" grep -i ^infra_envconfig /var/lib/cloud/instance/user-data.txt.i|awk -F'=' '{print $2}'")
       envconfig_chk1.run_command
       @envconfig_name1 = envconfig_chk1.stdout.chomp.gsub(/\s|"|'/, '')
       if @envconfig_name1.empty?
         envconfig_chk2 = Mixlib::ShellOut.new(" grep -i ^infra_envconfig /var/lib/cloud/instance/user-data.txt|awk -F'=' '{print $2}'")
         envconfig_chk2.run_command
         @envconfig_name2 = envconfig_chk2.stdout.chomp.gsub(/\s|"|'/, '')
         if @envconfig_name2.empty?
           envconfig_chk3 = Mixlib::ShellOut.new(" grep -i ^infra_envconfig /root/.client.rb|awk -F'=' '{print $2}'")
           envconfig_chk3.run_command
           @envconfig_name3 = envconfig_chk3.stdout.chomp.gsub(/\s|"|'/, '')
           if @envconfig_name3.empty?
             @envconfig_name3 = 'none'
           end
           return @envconfig_name3
         else
           return @envconfig_name2
         end
       else
         return @envconfig_name1
       end
     else
       return 'none'
     end
   end

   def self.role_name
     if ( File.exist?('/var/lib/cloud/instance/user-data.txt.i') || File.exist?('/var/lib/cloud/instance/user-data.txt') || File.exist?('/root/.client.rb') )
       rolename_chk1 = Mixlib::ShellOut.new(" grep -i ^infra_rolename /var/lib/cloud/instance/user-data.txt.i|awk -F'=' '{print $2}'")
       rolename_chk1.run_command
       @role_name1 = rolename_chk1.stdout.chomp.gsub(/\s|"|'/, '')
       if @role_name1.empty?
         rolename_chk2 = Mixlib::ShellOut.new(" grep -i ^infra_rolename /var/lib/cloud/instance/user-data.txt|awk -F'=' '{print $2}'")
         rolename_chk2.run_command
         @role_name2 = rolename_chk2.stdout.chomp.gsub(/\s|"|'/, '')
         if @role_name2.empty?
           rolename_chk3 = Mixlib::ShellOut.new(" grep -i ^infra_rolename /root/.client.rb|awk -F'=' '{print $2}'")
           rolename_chk3.run_command
           @role_name3 = rolename_chk3.stdout.chomp.gsub(/\s|"|'/, '')
           if @role_name3.empty?
             @role_name3 = 'none'
           end
           return @role_name3
         else
           return @role_name2
         end
       else
         return @role_name1
       end
     else
       return 'none'
     end
   end

   def self.conf_name
     if ( File.exist?('/var/lib/cloud/instance/user-data.txt.i') || File.exist?('/var/lib/cloud/instance/user-data.txt') || File.exist?('/root/.client.rb') )
       confname_chk1 = Mixlib::ShellOut.new(" grep -i ^infra_confname /var/lib/cloud/instance/user-data.txt.i|awk -F'=' '{print $2}'")
       confname_chk1.run_command
       @conf_name1 = confname_chk1.stdout.chomp.gsub(/\s|"|'/, '')
       if @conf_name1.empty?
         confname_chk2 = Mixlib::ShellOut.new(" grep -i ^infra_confname /var/lib/cloud/instance/user-data.txt|awk -F'=' '{print $2}'")
         confname_chk2.run_command
         @conf_name2 = confname_chk2.stdout.chomp.gsub(/\s|"|'/, '')
         if @conf_name2.empty?
           confname_chk3 = Mixlib::ShellOut.new(" grep -i ^infra_confname /root/.client.rb|awk -F'=' '{print $2}'")
           confname_chk3.run_command
           @conf_name3 = confname_chk3.stdout.chomp.gsub(/\s|"|'/, '')
           if @conf_name3.empty?
             @conf_name3 = 'none'
           end
           return @conf_name3
         else
           return @conf_name2
         end
       else
         return @conf_name1
       end
     else
       return 'none'
     end
   end

   def self.environment
     if ( File.exist?('/var/lib/cloud/instance/user-data.txt.i') || File.exist?('/var/lib/cloud/instance/user-data.txt') || File.exist?('/root/.client.rb'))
       envname_chk1 = Mixlib::ShellOut.new(" grep  ^environment /var/lib/cloud/instance/user-data.txt.i|awk -F'=' '{print $2}'")
       envname_chk1.run_command
       @env_name1 = envname_chk1.stdout.chomp.gsub(/\s|"|'/, '')
       if @env_name1.empty?
         envname_chk2 = Mixlib::ShellOut.new(" grep  ^environment /var/lib/cloud/instance/user-data.txt|awk -F'=' '{print $2}'")
         envname_chk2.run_command
         @env_name2 = envname_chk2.stdout.chomp.gsub(/\s|"|'/, '')
         if @env_name2.empty?
           envname_chk3 = Mixlib::ShellOut.new(" grep  ^environment /root/.client.rb|awk -F'=' '{print $2}'")
           envname_chk3.run_command
           @env_name3 = envname_chk3.stdout.chomp.gsub(/\s|"|'/, '')
           if @env_name3.empty?
             @env_name3 = 'Prod'
           end
           return @env_name3
         end
           return @env_name2
       else
         return @env_name1
       end
     else
       return 'Prod'
     end
   end

  def self.proxy(node)
    @tenancy = self.tenancy_name
    @instance = self.check_oci_or_not
    vmdet = self.vminfo(node)
    @region = vmdet[1]
    if  @instance == 'OCI'
      if  @tenancy == 'devapp' && @region == 'iad'
        return "iad-devappnew-proxy.appoci.oraclecorp.com:80", "False"
      elsif @tenancy == 'devapp' && @region == 'phx'
        return "phx-devappnew-proxy.appoci.oraclecorp.com:80", "False"
      elsif @tenancy == 'prodapp' && @region == 'iad'
        return "iad-prodapp-proxy.appoci.oraclecorp.com:80", "False"
      elsif @tenancy == 'prodapp' && @region == 'phx'
        return "phx-prodapp-proxy.appoci.oraclecorp.com:80", "False"
      elsif @tenancy == 'espsocicorpnonprod' && @region == 'iad'
        return "iadssprxnpin01-vip.proxyssiad.espsnonpiad.oraclevcn.com:80", "True"
      elsif @tenancy == 'externalnonprod' && @region == 'iad'
        return "iadssprxnpin01-vip.proxyssiad.externalnpssiad.oraclevcn.com:80", "True"
      elsif @tenancy == 'internalnonprod' &&  @region == 'iad'
        return "iad-internalnonprod-proxy.appoci.oraclecorp.com:80", "True"
      elsif @tenancy == 'pesharedservices' &&  @region == 'iad'
        return "iad-pesharedservices-proxy.appoci.oraclecorp.com:80", "True"
      elsif @tenancy == 'externalprod'  && @region == 'phx'
        return "phx-externalprod-proxy.appoci.oraclecorp.com:80", "True"
      elsif @tenancy == 'internalprod'   && @region == 'phx'
        return "phxssprxprin01-vip.proxyssphx.internalpssphx.oraclevcn.com:80", "True"
      elsif @tenancy == 'peappinternalprod'   && @region == 'phx'
        return "phx-peappinternalprod-proxy.appoci.oraclecorp.com:80", "True"
      elsif @tenancy == 'legalapp'  && @region == 'phx'
        return "", "True"
      elsif @tenancy == 'legalapp'  && @region == 'iad'
        return "", "True"
      elsif @tenancy == '' && @region == 'iad'
        return "iadvalue:80", "True"
      elsif @tenancy == '' && @region == 'phx'
        return "phxvalue:80", "True"
      else
        return "", "False"
      end
    else
      return "phxvalue:80", "True"
    end
  end  

  def self.appinfo
    if File.exist?('/root/.client.rb')
      app_list=['AppID', 'ApplicationName', 'AppShortName', 'EnvironmentType', 'infra_tenancy']
      app_info = Hash.new
      app_list.each do  |app|
        appinfo_chk = Mixlib::ShellOut.new("grep -i ^#{app} /root/.client.rb|awk -F'=' '{print $2}'")
        appinfo_chk.run_command
        appinfo_ret = appinfo_chk.stdout.chomp.gsub(/"|'/, '')
        app_info["#{app}"] = appinfo_ret if !appinfo_ret.empty?
      end
      return app_info
    end
  end

  def self.oci_metadata()
    oci_met1 = Mixlib::ShellOut.new("curl -sm 5 --retry 3 -H 'Authorization: Bearer Oracle' -L http://169.254.169.254/opc/v2/instance/")
    oci_met1.run_command
    oci_met = oci_met1.stdout
    if oci_met.empty?
      oci_met2 = Mixlib::ShellOut.new("curl -sm 5 --retry 3 -H 'Authorization: Bearer Oracle' -L http://169.254.169.254/opc/v1/instance/")
      oci_met2.run_command
      oci_met = oci_met2.stdout 
    end
    return JSON.parse(oci_met) if !oci_met.empty?
 end

  def self.oci_realmkey()
    @instance = self.check_oci_or_not
    if  @instance == 'OCI'
      oci_rel1 = Mixlib::ShellOut.new("curl -sm 5 --retry 3 -H 'Authorization: Bearer Oracle' -L http://169.254.169.254/opc/v2/instance/regionInfo/realmKey")
      oci_rel1.run_command
      oci_rel = oci_rel1.stdout
      if oci_rel.empty?
        oci_rel2 = Mixlib::ShellOut.new("curl -sm 5 --retry 3 -H 'Authorization: Bearer Oracle' -L http://169.254.169.254/opc/v1/instance/regionInfo/realmKey")
        oci_rel2.run_command
        oci_rel = oci_rel2.stdout
      end
      return oci_rel
    else
      return nil
    end
  end

  end
 
end
