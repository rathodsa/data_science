require "chef/handler"
require "chef/handler"
require 'json'
require 'net/http'
require 'uri'
require 'openssl'

class Chef
  class Handler
    class JsonFile < Chef::Handler

      attr_reader :config

      def initialize(config = {})
        @config = config
        @config[:path] ||= "/var/chef/reports"
      end

      def report
        if exception
          Chef::Log.error("Creating JSON exception report")
        else
          Chef::Log.info("Creating JSON run report")
        end

        `umount -l /tmp/common1`
        build_report_dir
        savetime = Time.now.strftime("%Y%m%d%H%M%S")
        File.open(File.join(config[:path], "chef-run-report-#{savetime}.json"), "w") do |file|

          # ensure start time and end time are output in the json properly in the event activesupport happens to be on the system
          run_data = JSON.parse(JSON.pretty_generate(data))
          if run_data['node']['automatic']['roles'].length > 0
            runlist=`echo #{run_data['node']['automatic']['expanded_run_list']}|sed 's/"//g' |sed 's/recipe//g'|tr -d '\"[]' |xargs|sed 's/ ::default//g'|sed 's/::default//g'|sed 's/,//g'`.chomp
            role_name=`echo #{run_data['node']['automatic']['roles']}|sed 's/"//g' |sed 's/recipe//g'|tr -d '\"[]'`.chomp+".json".to_s
          else
            runlist=`echo #{run_data['node']['run_list']}|sed 's/"//g' |sed 's/recipe//g'|tr -d '\"[]' |xargs|sed 's/,//g'`.chomp
            role_name=run_data['node']['normal']['name'].to_s
            if role_name =~ /json/i
              role_name=run_data['node']['normal']['name'].to_s
            else
              role_name=run_data['node']['normal']['name'].to_s+".json"
            end
          end
          except=run_data['exception'].to_s.tr('[]\`','')
          exception_cookbook=`echo "#{except.split(/\n/)[0]}.to_s" | awk -F'(' '{print $2}' |awk -F')' '{print $1}' |awk  '{print $1}'|awk -F'::default' '{print $1}'`.chomp
          if run_data['all_resources'].nil?
            allresources=1
          else
            allresources=run_data['all_resources'].length
          end
          #allresources=run_data['all_resources'].length
          cbstatus={}
          if allresources.to_i == 1 and run_data['exception'].to_s != ""
            runlist.split.each do |i|
              cbstatus[i] = "2"
            end
          elsif allresources.to_i > 1 and run_data['exception'].to_s == ""
            runlist.split.each do |i|
              cbstatus[i] = "0"
            end
          elsif allresources.to_i > 1  and run_data['exception'].to_s != ""
            success_cookbooks=`echo "#{runlist}" | awk -F"#{exception_cookbook}" '{print $1}'`.chomp
            skipped_cookbooks=`echo "#{runlist}" | awk -F"#{exception_cookbook}" '{print $2}'`.chomp
            success_cookbooks.split.each do |i|
              cbstatus[i] = "0"
            end
            cbstatus["#{exception_cookbook}"] = "1"
            skipped_cookbooks.split.each do |i|
              cbstatus[i] = "2"
            end
          else
            runlist.split(' ').each do |i|
              cbstatus[i] = "1"
            end
          end
          required_data={:service_name=>'chef_reports',:host_name=>run_data['node']['name'],:success=>run_data['success'].to_s,:ipaddress=>run_data['node']['automatic']['ipaddress'].to_s,:osversion=>run_data['node']['automatic']['platform_version'].to_s,:exception=>except.to_s,:role=>role_name,:cookbook_status=>cbstatus,:start_time=>run_data['start_time'].to_s,:end_time=>run_data['end_time'].to_s}
          file.puts Chef::JSONCompat.to_json_pretty(required_data)
          status=JSON.generate(required_data)
          unless run_data['node']['normal']['name'].empty? || run_data['node']['normal']['name'].nil?
            uri = URI.parse("https://logfuse-api.appoci.oraclecorp.com/api/v1/oitsvclog/")
            request = Net::HTTP::Post.new(uri)
            request.content_type = "application/json"
            request["Expect"] = "100-continue"
            request["Accept"] = "application/json"
            request["X-Api-Key"] = "ZXlKMGVYQWlPaUpLVjFRaUxDSmhiR2NpT2lKSVV6STFOaUo5LmV5SmxlSEFpT2pFM01EWTFPVGt5TVRFc0ltbGhkQ0k2TVRZME16VXlOekl4TVN3aWMzVmlJam95ZlEuZXBMWXpSeFoxa3N3UnkwYUZsQ0Y5U3lrQ0RfSEtXaWN2aUMwOXpNeGl5MA=="
            request.body = status
            req_options = {
              use_ssl: uri.scheme == "https",
              verify_mode: OpenSSL::SSL::VERIFY_NONE,
            }
            begin
              retries = 0
              response = Net::HTTP.start(uri.hostname, uri.port, req_options) do |http|
                http.request(request)
              end
              puts "Response code for first run: #{response.code}"
            rescue Errno::ECONNRESET => e
              if (retries += 1) <= 3
                response = Net::HTTP.start(uri.hostname, uri.port, req_options) do |http|
                  http.request(request)
                end
                puts "Response code for #{retries} run: #{response.code}"
                if response.code == "201"
                  retries = 4
                end
              end
            rescue => e
              if (retries += 1) <= 3
                response = Net::HTTP.start(uri.hostname, uri.port, req_options) do |http|
                  http.request(request)
                end
                puts "Response code for #{retries} run: #{response.code}"
                if response.code == "201"
                  retries = 4
                end
              end
            end
          end
        end
      end

      def build_report_dir
        unless File.exists?(config[:path])
          FileUtils.mkdir_p(config[:path])
          File.chmod(00700, config[:path])
        end
      end

    end
  end
end
