#
# Cookbook Name:: General_Lib_Functions
# Recipe:: default
#
# Copyright 2017, YOUR_COMPANY_NAME
#
# All rights reserved - Do Not Redistribute
# Author :  jagannadham.mahanti@oracle.com
#
# COMMENTING EVERYTHING HERE AS WE ARE NOT CALLING THESE FUNCTIONS, JUST USAGE

# GeneralLibs::VmFunctions.set_local_proxy : proxy should be enabled to run this
# lib functions, so setting command line proxy for now (for now not required)
# It returns vm is CLOUD or NONCLOUD,
#  Usage : variable=GeneralLibs::VmFunctions .check_cloudvm_or_not()

# It returns LOB,REGION,STORAGE FILER and ADE_SITENAME Details,
# Usage : variable=GeneralLibs::VmFunctions.vminfo(node), Keep node argument
# as it is

# It returns IPADDRESS GATEWAY details, Usage : variable=GeneralLibs::
# VmFunctions..networkinfo(node) keep node as it is

# It returns IPADDRESS FQDN HOSTNAME details, Usage :
# variable=GeneralLibs::VmFunctions.dnslookup(node) keep node argument as it is

# It retunrs HOSTNAME if you pass ipaddress,
# Usage : variable=GeneralLibs::VmFunctions.vmname("ipaddress")

# It returns IPADDRESS if you pass hostname,
# Usage : variable=GeneralLibs::VmFunctions.ipaddress("hostname")

# It returns Given host is VM or SERVER,
# Usage : variable=GeneralLibs::VmFunctions.vm_or_physical()

# It returns nearest yum repo server ,
# Usage : variable=GeneralLibs::VmFunctions.nearest_yum()
# It returns instance is OCI or not
# Usage : variable=GeneralLibs::VmFunctions.check_oci_or_not

# It returns tenancy information
# Usage : variable=GeneralLibs::VmFunctions.tenancy_name

# It returns netgroup information
# Usage : variable=GeneralLibs::VmFunctions.netgroup_details

# It returns applob information
# Usage : variable=GeneralLibs::VmFunctions.applob_details

# It returns emdslob information
# Usage : variable=GeneralLibs::VmFunctions.emdslob_details

# It returns environment config information
# Usage: variable=GeneralLibs::VmFunctions.envconfig_name

# It returns post provision role name information
# Usage: variable=GeneralLibs::VmFunctions.role_name

# It returns config role name information
# Usage: variable=GeneralLibs::VmFunctions.conf_name

# It returns config role name information
# Usage: variable=GeneralLibs::VmFunctions.conf_name

# It returns environment information
# Usage: variable=GeneralLibs::VmFunctions.environment

# It returns proxy information as list[proxy,proxy_value(True,False)]
# Usage: variable=GeneralLibs::VmFunctions.proxy(node)

# It returns OCI metadata as JSON Object
# variable=GeneralLibs::VmFunctions.oci_metadata
# puts variable['availabilityDomain']

# It returns GCSDT variables passed as Hash
# variable=GeneralLibs::VmFunctions.appinfo
# puts variable
# puts variable['AppID']

# It returns OCI Realmkey
# variable=GeneralLibs::VmFunctions.oci_realmkey
# puts variable
