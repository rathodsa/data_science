case node['platform_version'].to_i
when 6 
  default['suricata_pkg'] = [
    'suricata.x86_64'
    ]

  default['suricata_service'] = [
    'suricata'
    ]
   
else
  default['suricata_pkg'] = [
    'suricata.x86_64'
    ]
 
  default['suricata_service'] = [
    'suricata.service'
    ] 
end

default['s_user'] = 'suricata:x:497:497::/home/suricata:/sbin/nologin' 
default['s_group'] = 'suricata:x:497:suricata' 

vmdetails = GeneralLibs::VmFunctions.vminfo(node)
instance_type = GeneralLibs::VmFunctions.check_oci_or_not
region = vmdetails[1]
tenancy_name = GeneralLibs::VmFunctions.tenancy_name
default['suricata_install']['tenancy_name']['region'] = GeneralLibs::VmFunctions.proxy(node)[0]
