#
# Cookbook Name:: suricata_install
# Recipe:: default
#
# Copyright 2018, ORACLE
# Author : anilkumar.kv@oracle.com
# All rights reserved - Do Not Redistribute

include_recipe 'General_Lib_Functions'
instance_type = GeneralLibs::VmFunctions.check_oci_or_not
os_version = node['platform_version'].to_i

#Identify OS platform and Install Suricata RPMS

if node['kernel']['machine'] == 'x86_64' && node['platform'] == 'oracle' && node['platform_version'].to_i >= 6

  if GeneralLibs::VmFunctions.oci_realmkey.nil?
       realmkey_info = ''
  else
      realmkey_info = GeneralLibs::VmFunctions.oci_realmkey.chomp
  end
    
  if realmkey_info != 'oc2' 
	  # CREATING YUM REPOSITORY
          nearest_yum = GeneralLibs::VmFunctions.nearest_yum().chomp
	  yum_repository 'oitcustom' do
	    description "suricata_repo"
	    baseurl "#{nearest_yum}/pditrepos/LOB/OIT/OL#{os_version}/x86_64/"
	    metadata_expire=0
	    sslverify false
	    proxy '_none_'
	    action :create
	  end
  end

  suricata_g = node['s_group'].to_s.strip()
  group_c = `grep -i ^suricata /etc/group |wc -l`.chomp
  ldap_c = `egrep -iw 'ldap|sss' /etc/nsswitch.conf |wc -l`.chomp
  ruby_block 'suricata group update' do
    block do
      file = Chef::Util::FileEdit.new('/etc/group')
      file.insert_line_after_match("^sshd", "#{suricata_g}")
      file.write_file
    end
    only_if { ::File.exist?('/etc/group') && group_c.to_i < 1 && ldap_c.to_i >= 1 }
  end

  suricata_p = node['s_user'].to_s.strip() 
  pass_c = `grep -i ^suricata /etc/passwd |wc -l`.chomp
  ldap_c = `egrep -iw 'ldap|sss' /etc/nsswitch.conf |wc -l`.chomp
  ruby_block 'suricata user update' do
    block do
          fe = Chef::Util::FileEdit.new('/etc/passwd')
          fe.insert_line_after_match(/^sshd/, "#{suricata_p}")
          fe.write_file
    end
    only_if { ::File.exist?('/etc/passwd') && pass_c.to_i < 1 && ldap_c.to_i >= 1 }
  end
 
  check_entry = `grep "suricata" /var/spool/cron/root |wc -l`.chomp.to_i
  ruby_block 'Cleanup suricata from cron' do
      block do
        file = Chef::Util::FileEdit.new('/var/spool/cron/root')
        file.search_file_delete_line("suricata")
        file.write_file
      end
      only_if { check_entry >= 1 }
  end
  
  #Installing Packages
  execute "LANG setup" do
    command "export LC_ALL=en_US.UTF-8;export LANG=en_US.UTF-8"
    action  :run
    ignore_failure true
  end

  node['suricata_pkg'].each do |pkg|
    if os_version == 9 
      execute "suricata install" do
        command "dnf --disablerepo=* --enablerepo=ol9_developer_epel,ol9_developer_EPEL,ol9_baseos_latest,ol9_appstream,oitcustom --nogpgcheck --skip-broken -y install #{pkg}"
      end
    elsif os_version == 8
      execute "suricata install" do
        command "dnf --disablerepo=* --enablerepo=ol8_developer_epel,ol8_developer_EPEL,ol8_baseos_latest,ol8_appstream,oitcustom --nogpgcheck --skip-broken -y install #{pkg}"
      end
    elsif os_version == 7
      execute "suricata install" do
        command "yum --disablerepo=* --enablerepo=ol7_developer_epel,ol7_developer_EPEL,ol7_addons,ol7_latest,ol7_optional_latest,oitcustom --nogpgcheck --skip-broken -y install #{pkg}"
      end
    else 
      execute "suricata install" do
        command "yum --nogpgcheck --skip-broken -y install #{pkg}"
      end
    end
  end

  yum_repository 'oitcustom' do
    action :delete
    ignore_failure true
  end
else
  Chef::Log.info('PLATFORM NOT SUPPORTED')
end
