#
# Cookbook Name:: suricata_install
# Recipe:: default
#
# Copyright 2018, ORACLE
# Author : anilkumar.kv@oracle.com
# All rights reserved - Do Not Redistribute
include_recipe 'suricata_install::suricata_pkginstall'
include_recipe 'suricata_install::suricata_configure'
