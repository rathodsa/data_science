#
# Cookbook Name:: suricata_install
# Recipe:: default
#
# Copyright 2018, ORACLE
# Author : anilkumar.kv@oracle.com
# All rights reserved - Do Not Redistribute

include_recipe 'General_Lib_Functions'
instance_type = GeneralLibs::VmFunctions.check_oci_or_not
os_version = node['platform_version'].to_i
tenancy_name = GeneralLibs::VmFunctions.tenancy_name

if tenancy_name != 'none'
  if GeneralLibs::VmFunctions.envconfig_name == 'GITCOMPUTE'
    upfile = 'suricata-update-git.erb'
  else
    upfile = 'suricata-update-prod.erb'
  end
  if tenancy_name == 'prodapp'
    home_net = '    HOME_NET: "[100.114.32.0/19,100.114.64.0/19,100.114.160.0/20,100.114.192.0/20,100.112.32.0/19, 100.112.64.0/19,100.112.160.0/20,100.112.192.0/20,100.70.196.0/22,100.70.192.0/22,100.70.200.0/21,100.124.8.0/22,100.70.212.0/22, 100.70.208.0/22,100.70.216.0/21,100.123.8.0/22,100.70.244.0/22, 100.70.240.0/22,100.70.248.0/21,100.70.176.0/22,100.70.228.0/22,100.70.224.0/22,100.70.232.0/21,100.70.160.0/22]"'
  elsif tenancy_name == 'devapp'
    home_net = '    HOME_NET: "[100.95.0.0/19,100.95.32.0/19,100.95.64.0/19,100.95.96.0/19,100.93.0.0/19,100.93.32.0/19,100.93.64.0/20,100.93.96.0/20]"'
  elsif tenancy_name == 'legalapp'
    home_net = '    HOME_NET: "[100.114.24.0/25,140.84.0.0/16,172.28.0.0/16,10.79.0.0/16,192.168.0.0/16,100.112.24.0/25,140.84.0.0/16,172.28.0.0/16,10.79.0.0/16]"'
  else
    home_net = 'none'
  end
else
  if GeneralLibs::VmFunctions.envconfig_name == 'GITCOMPUTE'
    upfile = 'suricata-update-git.erb'
  else
    upfile = 'suricata-update.erb'
  end
  home_net = 'none'
end

if node['kernel']['machine'] == 'x86_64' && node['platform'] == 'oracle' && node['platform_version'].to_i >= 6

#Suricata Configuration files update based on OS Versions
    # Identify primary interface
    pinterface = `netstat -nr |grep ^0.0.0.0 |awk '{print $NF}'|uniq`.chomp.to_s
    inetaddr = "- interface: #{pinterface}"

    directory '/var/lib/suricata/' do
      owner 'suricata'
      group 'suricata'
      mode '2775'
    end

    directory '/var/lib/suricata/rules' do
      owner 'suricata'
      group 'suricata'
      mode '2775'
    end

    template '/etc/suricata/suricata.yaml' do
      source "suricata_#{os_version}.yaml.erb"
      owner 'suricata'
      group 'suricata'
      mode '600'
    end

    ruby_block 'replace interface in suricata.yaml' do
          block do
            fe = Chef::Util::FileEdit.new('/etc/suricata/suricata.yaml')
            fe.search_file_replace_line("- interface: ens3", "  #{inetaddr}")
            fe.write_file
          end
    end
    ruby_block 'Update sysconfig suricata' do
          block do
            de = Chef::Util::FileEdit.new('/etc/sysconfig/suricata')
            de.search_file_replace("eth0", "#{pinterface}")
            de.write_file
          end
          only_if { ::File.exist?('/etc/sysconfig/suricata') }
    end
    ruby_block 'replace HOME NET in suricata.yaml' do
          block do
            fe = Chef::Util::FileEdit.new('/etc/suricata/suricata.yaml')
            fe.search_file_replace_line('^    HOME_NET: .*', "#{home_net}")
            fe.write_file
          end
          only_if { home_net != 'none' }
    end

    template '/etc/suricata/update.yaml' do
      source "update.yaml.erb"
      owner 'suricata'
      group 'suricata'
      mode '600'
    end

    template '/etc/suricata/enable.conf' do
      source "enable.conf.erb"
      owner 'suricata'
      group 'suricata'
      mode '600'
    end

    template '/etc/suricata/disable.conf' do
      source "disable.conf.erb"
      owner 'suricata'
      group 'suricata'
      mode '600'
    end

    template '/usr/bin/suricata-update' do
      source "#{upfile}"
      owner 'suricata'
      group 'suricata'
      mode '755'
    end

    execute 'execute suricata-update' do
      command "/usr/bin/suricata-update --suricata /sbin/suricata"
      returns [0, 1]
    end

    if os_version == 8
      rules_path = '/etc/suricata/rules/'
      link '/etc/suricata/rules/suricata.rules' do
        to '/var/lib/suricata/rules/suricata.rules'
        link_type :symbolic
        not_if 'test -f /etc/suricata/rules/suricata.rules'
      end
    else
      rules_path = '/var/lib/suricata/rules/'
    end

    template "#{rules_path}local.rules" do
      source "local.rules.erb"
      owner 'suricata'
      group 'suricata'
      mode '600'
    end

#Enable suricata service and do not do anything in GIT if service is masked and updating cron job
  if GeneralLibs::VmFunctions.envconfig_name == 'GITCOMPUTE'
    node['suricata_service'].each do |srv|
      service "#{srv}" do
         action [:enable, :start]
         ignore_failure true
      end
    end
  else
    node['suricata_service'].each do |srv|
      service "#{srv}" do
         action [:enable, :start]
      end
    end
  end

  template '/usr/local/suricata_cron' do
    source 'suricata_cron.erb'
    owner 'root'
    group 'root'
    mode '644'
  end

  link '/etc/cron.d/suricata_cron' do
    to '/usr/local/suricata_cron'
    link_type :symbolic
    not_if 'test -f /etc/cron.d/suricata_cron'
  end

  template '/etc/logrotate.d/suricata' do
    source 'suricata_logrotate.erb'
    owner 'root'
    group 'root'
    mode '644'
  end

else
  Chef::Log.info('PLATFORM NOT SUPPORTED')
end
