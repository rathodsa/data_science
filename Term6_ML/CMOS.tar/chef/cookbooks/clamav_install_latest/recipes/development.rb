#
# Cookbook Name:: clamav_install_latest
# Recipe:: default
#
# Copyright 2018, ORACLE
# Author : anilkumar.kv@oracle.com
# All rights reserved - Do Not Redistribute

#Common function to get nearest yum server and to identify a host as OCI or not
include_recipe 'General_Lib_Functions'
include_recipe 'clamav_install_latest::create_user'
instance_type = GeneralLibs::VmFunctions.check_oci_or_not
nearest_yum = GeneralLibs::VmFunctions.nearest_yum().chomp
region_emagent = GeneralLibs::VmFunctions.vminfo(node)
freshclam_srv = node['clamav_install']['fresh_clam_server']
ipaddress_srv = node['ipaddress']
os_version = node['platform_version'].to_i

enforce_status = `cat  /etc/selinux/config | grep -w SELINUX | grep -v '#' | awk -F'=' '{print $2}'`
current_max_watchers = `cat /proc/sys/fs/inotify/max_user_watches`

total_mem_size = `free -g | grep -i mem |  awk '{print $2}'`.chomp
if total_mem_size.to_i < 4
   max_user_watchers_count = 262144
elsif total_mem_size.to_i >= 4 && total_mem_size.to_i < 8
   max_user_watchers_count = 524288
elsif total_mem_size.to_i >= 8 &&  total_mem_size.to_i < 14
   max_user_watchers_count = 1048576
else
   max_user_watchers_count = 2097152
end

if current_max_watchers.to_i > max_user_watchers_count
  max_user_watchers_count = current_max_watchers.to_i
end

#Identify OS platform and Install clamav RPMS

if  node['platform'] == 'oracle' && node['platform_version'].to_i >= 6 || node['platform_version'].to_i == 3
  # Remove a file to confirm execution of Dev recipe on instances
  file '/root/.clamav_prod' do
    action :delete
  end

  # Unlink /etc/cron.d/clamd_scanner_cron 
  if File.symlink?('/etc/cron.d/clamd_scanner_cron')
    link '/etc/cron.d/clamd_scanner_cron' do
      action :delete
    end
  end

  # Allow antivirus scan in selinux if it is enforcing
  if node['platform_version'].to_i >= 7
    execute 'Allow antivirus scan as selinux is enforcing' do
      command '/usr/sbin/setsebool -P antivirus_can_scan_system 1'
      only_if {enforce_status.chomp == "enforcing"}
    end
  end

  # REMOVE EXECUTABLE PERMISSIONS FOR A SERVICE
  execute 'Remove executable permissions to clammonitor service' do
    command 'chmod -x /etc/systemd/system/clammonitor.service'
    only_if 'ls -l /etc/systemd/system/clammonitor.service'
    ignore_failure true
  end

  ##CLEAN UP CLAMAV FILES
  node["clamav"]["remove_files"].each do |rm_file|
     file "#{rm_file}" do
       action :delete
     end
  end

  ###CLEANING UP CLAMAV FROM CRON
  check_entry = `grep "clam" /var/spool/cron/root |wc -l`.chomp.to_i
  ruby_block 'Cleanup clam from cron' do
      block do
        file = Chef::Util::FileEdit.new('/var/spool/cron/root')
        file.search_file_delete_line("clam")
        file.write_file
      end
      only_if { check_entry >= 1 }
  end

###DELETE CLAMAV UPDATE IN CRON
  execute 'delete cron entry for clam update' do
    command 'rm -rf /etc/cron.d/clamav-update'
  end

#CREATE A CLAMAV DIRECTORY IN /var/log AND LOCAL SOCKET DIRECTORY

  directory '/var/log/clamav' do
    owner lazy { node['clamav']['user'] }
    group lazy { node['clamav']['group'] }
    mode '755'
  end

  directory '/run/clamd.scan' do
    owner lazy { node['clamav']['user'] }
    group lazy { node['clamav']['group'] }
    mode '755'
    recursive true
  end

  directory '/var/lib/clamav' do
    owner lazy { node['clamav']['user'] }
    group lazy { node['clamav']['group'] }
    mode '755'
    recursive true
  end

  execute 'change /run permissions' do
    command 'chmod 755 /run'
  end

  file "/var/log/clamav/freshclam.log" do
     mode '755'
     owner lazy { node['clamav']['user'] }
     group lazy { node['clamav']['group'] }
     action :touch
     not_if {File.exist?('/var/log/clamav/freshclam.log')}
  end

  execute 'change permissions of clamav directories' do
    command lazy { "chown -R #{node["clamav"]["user"]}:#{node["clamav"]["group"]} /var/log/clamav; chown -R #{node["clamav"]["user"]}:#{node["clamav"]["group"]} /var/lib/clamav;chown -R #{node["clamav"]["user"]}:#{node["clamav"]["group"]} /run/clamd.scan" }
  end

#ClamAV Configuration files update based on OS Versions
  template "#{node["clamav"]["freshclam"]["conf_location"]}" do
    source "#{node["clamav"]["freshclam_config"]}"
    owner 'root'
    group 'root'
    variables(freshclam_server: freshclam_srv, user_srv: lazy {"#{node["clamav"]["user"]}"})
    mode '644'
  end

  template "#{node["clamav"]["scan"]["conf_location"]}" do
    source "#{node["clamav"]["scan_config"]["dev"]}"
    owner 'root'
    group 'root'
    variables(ipaddress_server: ipaddress_srv, user_srv: lazy {"#{node["clamav"]["user"]}"})
    mode '644'
  end

  if node['platform_version'].to_i == 6 || node['platform_version'].to_i == 3
    execute 'execute freshclam' do
      command "freshclam -d"
      returns [0, 1]
      not_if 'ps -ef |grep freshclam |grep -v "grep"'
    end
  end

#Enable clamav service and updating cron job
  node['clam_service']['dev'].each do |srv|
     service "#{srv}" do
       #supports status: true
       action [:enable]
     end
  end

  execute 'inotify max user watches entry to sysctl.conf' do
     command "echo #{max_user_watchers_count} | sudo tee -a /proc/sys/fs/inotify/max_user_watches; sed -i \"/fs.inotify.max_user_watches/d\" /etc/sysctl.conf; echo -e \"fs.inotify.max_user_watches=#{max_user_watchers_count}\">> /etc/sysctl.conf"
     not_if "grep -w fs.inotify.max_user_watches=#{max_user_watchers_count} /etc/sysctl.conf"
  end

  template "#{node["clamav"]["scan_script_loc"]["dev"]}" do
    source "#{node["clamav"]["script"]["dev"]}"
    owner 'root'
    group 'root'
    mode '755'
  end 
  
  template "#{node["clamav"]["start_cron_loc"]["dev"]}" do
    source "#{node["clamav"]["start_cron"]["dev"]}"
    owner 'root'
    group 'root'
    mode '755'
  end

  template '/etc/logrotate.d/clamd-log' do
    source 'clamd-log.erb'
    owner 'root'
    group 'root'
    mode '644'
    variables(user_srv: lazy {"#{node["clamav"]["user"]}"})
  end

  template '/etc/logrotate.d/freshclam-log' do
    source 'freshclam-log.erb'
    owner 'root'
    group 'root'
    mode '644'
  end
  
  cron_d 'clamd_scanner_cron' do
    action :create
    minute "#{node['minute']}"
    hour "#{node['hour']}"
    if node['platform_version'].to_i < 7
      weekday '0-5'
    else
      weekday '0-6'
    end
    user 'root'
    command "printf -v RANDOM \"\\%d\" \"0x$(hostname | sha1sum | cut -c1-4)\"; sleep ${RANDOM:1:2}m; #{node["clamav"]["scan_script_loc"]["dev"]} > /dev/null 2>&1"
  end

  if node['platform_version'].to_i < 7
    cron_d 'weekly_clamd_scanner_cron' do
      action :create
      minute "#{node['minute']}"
      hour "#{node['hour']}"
      weekday '6'
      user 'root'
      command "printf -v RANDOM \"\\%d\" \"0x$(hostname | sha1sum | cut -c1-4)\"; sleep ${RANDOM:1:2}m; #{node["clamav"]["scan_script_loc"]["dev"]} --weekly > /dev/null 2>&1"
    end
  end

  cron_d 'start_clamav_service' do
    action :create
    minute '*/30'
    hour '2-23'
    user 'root'
    command "#{node["clamav"]["start_cron_loc"]["dev"]} > /dev/null 2>&1"
  end

  if node['platform_version'].to_i > 6
    execute 'Run clamav exclusion script' do
      command "#{node["clamav"]["scan_script_loc"]["dev"]} --exclusion"
    end
  end

  if node['platform_version'].to_i > 6
    directory '/etc/systemd/system/clamd@.service.d' do
      owner "root"
      group "root"
      mode '755'
    end
    template '/etc/systemd/system/clamd@.service.d/override.conf' do
      source "#{node["clamav"]["cpulimits_78"]}"
      owner "root"
      group "root"
      mode '644'
      notifies :run,'execute[reload systemd]',:immediately
    end
    execute 'reload systemd' do
      command '/bin/systemctl daemon-reload'
      action :nothing
    end
  else
    directory '/etc/cgconfig.d' do
      owner lazy {"#{node["clamav"]["user"]}"}
      group lazy {"#{node["clamav"]["group"]}"}
      mode '755'
    end

    template '/etc/sysconfig/clamd' do
      source '6_cpu_nice_clam.erb'
      owner "root"
      group "root"
      mode '644'
    end

    template '/etc/cgconfig.d/clamd' do
      source '6_limit_clamd.erb'
      owner lazy {"#{node["clamav"]["user"]}"}
      group lazy {"#{node["clamav"]["group"]}"}
      mode '644'
      notifies :run,'execute[restart cgroup service]',:immediately
    end
  
    execute 'restart cgroup service' do
      command '/sbin/chkconfig cgconfig on;/sbin/service cgconfig restart'
      action :nothing
      ignore_failure true
    end
  end

else
  Chef::Log.info('PLATFORM NOT SUPPORTED')
end
