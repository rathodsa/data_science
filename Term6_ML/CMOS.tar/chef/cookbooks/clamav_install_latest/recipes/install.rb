#
# Cookbook Name:: clamav_install_latest
# Recipe:: default
#
# Copyright 2018, ORACLE
# Author : anilkumar.kv@oracle.com
# All rights reserved - Do Not Redistribute

#Common function to get nearest yum server and to identify a host as OCI or not
include_recipe 'General_Lib_Functions'
instance_type = GeneralLibs::VmFunctions.check_oci_or_not
region_emagent = GeneralLibs::VmFunctions.vminfo(node)
freshclam_srv = node['clamav_install']['fresh_clam_server']


#Identify OS platform and Install clamav RPMS

if node['platform'] == 'oracle' && node['platform_version'].to_i >= 6 || node['platform_version'].to_i == 3
    if GeneralLibs::VmFunctions.oci_realmkey.nil?
       realmkey_info = ''
    else
      realmkey_info = GeneralLibs::VmFunctions.oci_realmkey.chomp
    end
    
    if realmkey_info != 'oc2' 
          nearest_yum = GeneralLibs::VmFunctions.nearest_yum().chomp
	  # CREATING YUM REPOSITORY
	  os_version = node['platform_version'].to_i
	  directory '/etc/yum.repos.d' do
	    owner 'root'
	    group 'root'
	    mode '0755'
	    action :create
	  end
	  if node['platform_version'].to_i == 3
	    yum_repository 'clamav_repo' do
	      description "clamav_repo"
	      baseurl "#{nearest_yum}/pditrepos/LOB/DIS/OL6/clamav/x86_64/"
	      make_cache false
	      metadata_expire=0
	      sslverify false
	      action :create
	    end
	    yum_repository 'ol6_latest' do
	      description "ol6_latest"
	      baseurl "#{nearest_yum}/pditrepos/OracleLinux/OL6/latest/x86_64/"
	      make_cache false
	      metadata_expire=0
	      sslverify false
	      action :create
	    end
	  end
	  if node['platform_version'].to_i == 6
	    yum_repository 'clamav_repo' do
	      description "clamav_repo"
	      baseurl "#{nearest_yum}/pditrepos/LOB/DIS/OL6/clamav/x86_64/"
	      make_cache false
	      metadata_expire=0
	      sslverify false
	      action :create
	    end
	  end
    end

  if node['platform_version'].to_i >= 8
    node['clamav_pkg'].each do |pkg|
      execute "clamav install" do
        command "dnf --disablerepo=* --nogpgcheck --enablerepo=#{node['clamav_enable_repos']} --skip-broken -y install #{pkg}"
      end
    end
  elsif node['platform_version'].to_i == 7
    node['clamav_pkg'].each do |pkg|
      execute "clamav install" do
        command "yum --disablerepo=* --nogpgcheck --enablerepo=#{node['clamav_enable_repos']} --skip-broken -y install #{pkg}"
      end
    end
  else
    node['clamav_pkg'].each do |pkg|
      execute "clamav install" do
        command "yum --disablerepo=* -c /etc/yum.repos.d/clamav_repo.repo --enablerepo=#{node['clamav_enable_repos']} --nogpgcheck --skip-broken -y install #{pkg}"
      end
    end
  end

  if node['platform_version'].to_i == 6 || node['platform_version'].to_i == 3
    yum_repository 'clamav_repo' do
      action :delete
    end
  end

  if node['platform_version'].to_i == 3
    yum_repository 'ol6_latest' do
      action :delete
    end
  end
else
  Chef::Log.info('PLATFORM NOT SUPPORTED')
end
