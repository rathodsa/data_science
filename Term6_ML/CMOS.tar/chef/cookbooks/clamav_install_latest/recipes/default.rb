#
# Cookbook Name:: clamav_install_latest
# Recipe:: default
#
# Copyright 2018, ORACLE
# Author : v.d.v.srikanth.grandhi@oracle.com
# All rights reserved - Do Not Redistribute
include_recipe 'clamav_install_latest::install'
prod_recipe_check=`ls -ld /root/.clamav_prod;echo $?`
if prod_recipe_check.chomp.to_i == 0
  include_recipe 'clamav_install_latest::production' 
else 
  include_recipe 'clamav_install_latest::development'
end
