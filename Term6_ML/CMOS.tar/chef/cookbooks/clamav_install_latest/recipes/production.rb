#
# Cookbook Name:: clamav_install_latest
# Recipe:: default
#
# Copyright 2018, ORACLE
# Author : anilkumar.kv@oracle.com
# All rights reserved - Do Not Redistribute

#Common function to get nearest yum server and to identify a host as OCI or not
include_recipe 'General_Lib_Functions'
include_recipe 'clamav_install_latest::create_user'
instance_type = GeneralLibs::VmFunctions.check_oci_or_not
vmdetails = GeneralLibs::VmFunctions.vminfo(node)
region = vmdetails[1]
freshclam_srv = node['clamav_install']['fresh_clam_server']
ipaddress_srv = node['ipaddress']
os_version = node['platform_version'].to_i
enforce_status = `cat  /etc/selinux/config | grep -w SELINUX | grep -v '#' | awk -F'=' '{print $2}'`

#Identify OS platform and Install clamav RPMS

if  node['platform'] == 'oracle' && node['platform_version'].to_i >= 6 || node['platform_version'].to_i == 3

  # Create a file to confirm execution of Prod recipe on instances
  file '/root/.clamav_prod' do
    action :touch
  end

  # Unlink /etc/cron.d/clamd_scanner_cron 
  if File.symlink?('/etc/cron.d/clamd_scanner_cron')
    link '/etc/cron.d/clamd_scanner_cron' do
      action :delete
    end
  end

  # Allow antivirus scan in selinux if it is enforcing
  if node['platform_version'].to_i >= 7
    execute 'Allow antivirus scan as selinux is enforcing' do
      command '/usr/sbin/setsebool -P antivirus_can_scan_system 1'
      only_if {enforce_status.chomp == "enforcing"}
    end
  end

  # REMOVE EXECUTABLE PERMISSIONS FOR A SERVICE
  execute 'Remove executable permissions to clammonitor service' do
    command 'chmod -x /etc/systemd/system/clammonitor.service'
    only_if 'ls -l /etc/systemd/system/clammonitor.service'
    ignore_failure true
  end

  # Disable Clamonacc service
  service 'clamav-clamonacc.service' do
     action [:stop, :disable]
  end 
  ##CLEAN UP CLAMAV FILES
  node["clamav"]["remove_files"].each do |rm_file|
     file "#{rm_file}" do
       action :delete
     end
  end

  ###CLEANING UP CLAMAV FROM CRON
  check_entry = `grep "clam" /var/spool/cron/root |wc -l`.chomp.to_i
  ruby_block 'Cleanup clam from cron' do
      block do
        file = Chef::Util::FileEdit.new('/var/spool/cron/root')
        file.search_file_delete_line("clam")
        file.write_file
      end
      only_if { check_entry >= 1 }
  end

###DELETE CLAMAV UPDATE IN CRON
  execute 'delete cron entry for clam update' do
    command 'rm -rf /etc/cron.d/clamav-update'
  end

#CREATE A CLAMAV DIRECTORY IN /var/log AND LOCAL SOCKET DIRECTORY

  directory '/var/log/clamav' do
    owner lazy { node['clamav']['user'] }
    group lazy { node['clamav']['group'] }
    mode '755'
  end

  directory '/run/clamd.scan' do
    owner lazy { node['clamav']['user'] }
    group lazy { node['clamav']['group'] }
    mode '755'
    recursive true
  end

  directory '/var/lib/clamav' do
    owner lazy { node['clamav']['user'] }
    group lazy { node['clamav']['group'] }
    mode '755'
    recursive true
  end

  execute 'change /run permissions' do
    command 'chmod 755 /run'
  end

  file "/var/log/clamav/freshclam.log" do
     mode '755'
     owner lazy { node['clamav']['user'] }
     group lazy { node['clamav']['group'] }
     action :touch
     not_if {File.exist?('/var/log/clamav/freshclam.log')}
  end

  execute 'change permissions of clamav directories' do
    command lazy { "chown -R #{node["clamav"]["user"]}:#{node["clamav"]["group"]} /var/log/clamav; chown -R #{node["clamav"]["user"]}:#{node["clamav"]["group"]} /var/lib/clamav;chown -R #{node["clamav"]["user"]}:#{node["clamav"]["group"]} /run/clamd.scan" }
  end

#ClamAV Configuration files update based on OS Versions
  template "#{node["clamav"]["freshclam"]["conf_location"]}" do
    source "#{node["clamav"]["freshclam_config"]}"
    owner 'root'
    group 'root'
    variables(freshclam_server: freshclam_srv, user_srv: lazy {"#{node["clamav"]["user"]}"})
    mode '644'
  end

  template "#{node["clamav"]["scan"]["conf_location"]}" do
    source "#{node["clamav"]["scan_config"]["prod"]}"
    owner 'root'
    group 'root'
    variables(ipaddress_server: ipaddress_srv, user_srv: lazy {"#{node["clamav"]["user"]}"})
    mode '644'
  end

  if node['platform_version'].to_i == 6 || node['platform_version'].to_i == 3
    execute 'execute freshclam' do
      command "freshclam -d"
      returns [0, 1]
      not_if 'ps -ef |grep freshclam |grep -v "grep"'
    end
  end

#Enable clamav service and updating cron job

  node['clam_service']['prod'].each do |srv|
     service "#{srv}" do
       #supports status: true
       action [:enable]
     end
  end

  template "#{node["clamav"]["scan_script_loc"]["prod"]}" do
    source "#{node["clamav"]["script"]["prod"]}"
    owner 'root'
    group 'root'
    mode '755'
  end 
  
  template "#{node["clamav"]["start_cron_loc"]["prod"]}" do
    source "#{node["clamav"]["start_cron"]["prod"]}"
    owner 'root'
    group 'root'
    mode '755'
  end


  template '/etc/logrotate.d/clamd-log' do
    source 'clamd-log.erb'
    owner 'root'
    group 'root'
    mode '644'
    variables(user_srv: lazy {"#{node["clamav"]["user"]}"})
  end

  template '/etc/logrotate.d/freshclam-log' do
    source 'freshclam-log.erb'
    owner 'root'
    group 'root'
    mode '644'
  end

  cron_d 'clamd_scanner_cron' do
    action :create
    minute "#{node['minute']}"
    hour "#{node['hour']}"
    user 'root'
    command "printf -v RANDOM \"\\%d\" \"0x$(hostname | sha1sum | cut -c1-4)\"; sleep ${RANDOM:1:2}m; #{node["clamav"]["scan_script_loc"]["prod"]} > /dev/null 2>&1"
  end

  cron_d 'start_clamav_service' do
    action :create
    minute '*/30'
    hour '2-23'
    user 'root'
    command "#{node["clamav"]["start_cron_loc"]["prod"]} > /dev/null 2>&1"
  end

  if node['platform_version'].to_i > 6
    directory '/etc/systemd/system/clamd@.service.d' do
      owner "root"
      group "root"
      mode '755'
    end
    template '/etc/systemd/system/clamd@.service.d/override.conf' do
      source "#{node["clamav"]["cpulimits_78"]}"
      owner "root"
      group "root"
      mode '644'
      notifies :run,'execute[reload systemd]',:immediately
    end
    execute 'reload systemd' do
      command '/bin/systemctl daemon-reload'
      action :nothing
    end
  else
    directory '/etc/cgconfig.d' do
      owner lazy {"#{node["clamav"]["user"]}"}
      group lazy {"#{node["clamav"]["group"]}"}
      mode '755'
    end

    template '/etc/sysconfig/clamd' do
      source '6_cpu_nice_clam.erb'
      owner "root"
      group "root"
      mode '644'
    end

    template '/etc/cgconfig.d/clamd' do
      source '6_limit_clamd.erb'
      owner lazy {"#{node["clamav"]["user"]}"}
      group lazy {"#{node["clamav"]["group"]}"}
      mode '644'
      notifies :run,'execute[restart cgroup service]',:immediately
    end

    execute 'restart cgroup service' do
      command '/sbin/chkconfig cgconfig on;/sbin/service cgconfig restart'
      action :nothing
      ignore_failure true
    end
  end

else
  Chef::Log.info('PLATFORM NOT SUPPORTED')
end
