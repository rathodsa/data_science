# Create CLAMAV User
if node['platform_version'].to_i < 7
  execute 'Create clamav Group' do
    command '/usr/sbin/lgroupadd -r clamav'
    not_if 'grep -w "clamav:x" /etc/group'
  end
  execute 'Create clamav User' do
    command '/usr/sbin/luseradd -r -g clamav -d /var/lib/clamav -s /sbin/nologin -c "Clam Anti Virus Checker" clamav'
    not_if 'grep -w "clamav:x" /etc/passwd'
  end
else
  execute 'Create virusgroup Group' do
    command '/usr/sbin/lgroupadd -r virusgroup'
    not_if 'grep -w "virusgroup:x" /etc/group'
  end
  execute 'Create clamscan Group' do
    command '/usr/sbin/lgroupadd -r clamscan'
    not_if 'grep -w "clamscan:x" /etc/group'
  end
  execute 'Create clamscan User' do
    command '/usr/sbin/luseradd -r -g clamscan -d / -s /sbin/nologin -c "Clamav scanner user" clamscan'
    not_if 'grep -w "clamscan:x" /etc/passwd'
  end
  execute 'Add virusgroup to clamscan user' do
    command '/usr/sbin/usermod clamscan -a -G virusgroup'
    ignore_failure true
  end
end

ruby_block "identify clamav user" do
  block do
      if node['platform_version'].to_i > 6
        id_check=`id clamscan;echo $?`
        if id_check.chomp.to_i == 0
         node.force_default["clamav"]["user"] = "clamscan"
         node.force_default["clamav"]["group"] = `id -gn clamscan`.chomp.to_s
        else
          cid_check=`id clamav;echo $?`
          if cid_check.chomp.to_i == 0
           node.force_default["clamav"]["user"] = "clamav"
           node.force_default["clamav"]["group"] = `id -gn clamav`.chomp.to_s
          end
        end
      else
        cid_check=`id clamav;echo $?`
        if cid_check.chomp.to_i == 0
         node.force_default["clamav"]["user"] = "clamav"
         node.force_default["clamav"]["group"] = `id -gn clamav`.chomp.to_s
        end
      end
  end
  action :create
end
