name             'clamav_install_latest'
maintainer       'Oracle IT Group'
maintainer_email 'anilkumar.kv@oracle.com'
license          'All rights reserved'
description      'Installs/Configures clamav_install_latest'
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          '0.1.0'
depends 'General_Lib_Functions'
