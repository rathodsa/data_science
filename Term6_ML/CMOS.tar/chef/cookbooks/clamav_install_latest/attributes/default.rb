
# TENANCY NAME AND OEM DIRECTORY CHECK
tenancy_name = GeneralLibs::VmFunctions.tenancy_name
oem_dir_check=`ls -ld /oem;echo $?`

# ENABLE REPOS AS PER OS VERSION
case node['platform_version'].to_i
when 8
  default['clamav_enable_repos'] = "ol8_baseos_latest,ol8_developer_epel,ol8_appstream,ol8_developer_EPEL"
when 9
  default['clamav_enable_repos'] = "ol9_baseos_latest,ol9_developer_epel,ol9_appstream"
when 7
  default['clamav_enable_repos'] = "ol7_latest,ol7_developer_epel,ol7_developer_EPEL"
when 6,3
  default['clamav_enable_repos'] = "ol6_latest,clamav_repo"
end

# SERVICES AND PACKAGES INFO FOR CLAMAV
case node['platform_version'].to_i
when 6,3 
  default['clamav_pkg'] = [
    'clamav',
    'clamd',
    'libcgroup'
    ]

  default['clam_service']['dev'] = [
    'clamd'
    ]
  default['clam_service']['prod'] = [
    'clamd'
    ]
else
  default['clamav_pkg'] = [
    'clamav',
    'clamd',
    'clamav-update'
    ]
 
  default['clam_service']['dev'] = [
    'clamd@scan.service',
    'clamav-clamonacc',
    'clamonacc',
    'clamav-freshclam'
    ] 
  default['clam_service']['prod'] = [
    'clamd@scan.service',
    'clamav-freshclam'
    ]
end

# DECLARING LDAP URLS BASED ON REGIONS
vmdetails = GeneralLibs::VmFunctions.vminfo(node)
region = vmdetails[1]

# DECLARING LDAP URLS BASED ON REGIONS
vmdetails = GeneralLibs::VmFunctions.vminfo(node)
region = vmdetails[1]

# FRESHCLAM REGIONAL OBJECT STORAGE URL
if region == "phx"
  default['prod_freshclam_url'] = "https://objectstorage.us-phoenix-1.oraclecloud.com/n/idtj03adm895/b/freshclam/o"
elsif region == "iad"
  default['prod_freshclam_url'] = "https://objectstorage.us-ashburn-1.oraclecloud.com/n/idtj03adm895/b/freshclam/o"
elsif region == "bom"
  default['prod_freshclam_url'] = "https://objectstorage.ap-mumbai-1.oraclecloud.com/n/idtj03adm895/b/freshclam/o"
elsif region == "lhr"
  default['prod_freshclam_url'] = "https://objectstorage.uk-london-1.oraclecloud.com/n/idtj03adm895/b/freshclam/o"
elsif region == "us-langley-1"
  default['prod_freshclam_url'] = "https://objectstorage.us-ashburn-1.oraclecloud.com/n/idtj03adm895/b/freshclam/o"
elsif region == "us-luke-1"
  default['prod_freshclam_url'] = "https://objectstorage.us-phoenix-1.oraclecloud.com/n/idtj03adm895/b/freshclam/o"
else
  default['prod_freshclam_url'] = "https://objectstorage.us-phoenix-1.oraclecloud.com/n/idtj03adm895/b/freshclam/o"
end

if region == "phx"
  default['dev_freshclam_url'] = "https://objectstorage.us-phoenix-1.oraclecloud.com/n/peo/b/freshclam/o"
else
  default['dev_freshclam_url'] = "https://objectstorage.us-ashburn-1.oraclecloud.com/n/peo/b/freshclam/o"
end


# FRESHCLAM SERVER INFO AND PROXY SETUP IN FRESHCLAM.CONF
if region == 'colo' || region == 'colo_dr'
  case node['platform_version'].to_i
  when 6,3
    default['clamav_install']['fresh_clam_server'] = default['prod_freshclam_url']
    default['proxy_server'] = "HTTPProxyServer acamv0009.us.oracle.com"
    default['proxy_port'] = "HTTPProxyPort 8080"
  else
    default['clamav_install']['fresh_clam_server'] = default['prod_freshclam_url']
    default['proxy_server'] = ""
    default['proxy_port'] = ""
  end
else
  case tenancy_name
  when 'devapp','externalnonprod','prodapp'
     default['clamav_install']['fresh_clam_server'] = default['prod_freshclam_url']
     default['proxy_server'] = ""
     default['proxy_port'] = "HTTPProxyPort 9999"
  when 'espsocicorpnonprod'
     default['clamav_install']['fresh_clam_server'] = default['prod_freshclam_url']
     default['proxy_server'] = "HTTPProxyServer iadcncavprin01.avssiad.espsnonpiad.oraclevcn.com"
     default['proxy_port'] = "HTTPProxyPort 8080"
  when 'internalnonprod'
     default['clamav_install']['fresh_clam_server'] = default['prod_freshclam_url']
     default['proxy_server'] = "HTTPProxyServer phxapcavprin01.avssphx.peappintprodphx.oraclevcn.com"
     default['proxy_port'] = "HTTPProxyPort 8080"
  when 'internalprod'
     default['clamav_install']['fresh_clam_server'] = default['prod_freshclam_url']
     default['proxy_server'] = "HTTPProxyServer phxapcavprin01.avssphx.peappintprodphx.oraclevcn.com"
     default['proxy_port'] = "HTTPProxyPort 80"
  when 'peappinternalprod'
     default['clamav_install']['fresh_clam_server'] = default['prod_freshclam_url']
     default['proxy_server'] = "HTTPProxyServer phxapcavprin01.avssphx.peappintprodphx.oraclevcn.com"
     default['proxy_port'] = "HTTPProxyPort 8080"
  when 'cmosusgovdod'
     default['clamav_install']['fresh_clam_server'] = default['prod_freshclam_url']
     default['proxy_server'] = ""
     default['proxy_port'] = ""
  when 'pesharedservices'
     if region == "phx"
       default['clamav_install']['fresh_clam_server'] = default['prod_freshclam_url']
       default['proxy_server'] = "HTTPProxyServer phxpsavprin01.ssavphx.pesharedserphx.oraclevcn.com"
       default['proxy_port'] = "HTTPProxyPort 8080"
     else
       default['clamav_install']['fresh_clam_server'] = default['prod_freshclam_url']
       default['proxy_server'] = ""
       default['proxy_port'] = "HTTPProxyPort 9999"
     end
  else
    default['clamav_install']['fresh_clam_server'] = default['dev_freshclam_url']
    default['proxy_server'] = ""
    default['proxy_port'] = ""
  end
end

# FRESHCLAM.CONF TEMPLATE AND CONFIGURATION FILE LOCATION
default["clamav"]["freshclam_config"] = "#{node['platform_version'].to_i}_freshclam.conf.erb"
default["clamav"]["freshclam"]["conf_location"] = "/etc/freshclam.conf"

# SCAN.CONF, CLAMD_SCAN SCRIPT TEMPLATES AND CONFIGURATION FILE LOCATION FOR SCAN.CONF
case node['platform_version'].to_i
when 6,3
  default["clamav"]["scan_config"]["dev"] = "6_clamd_dev.conf.erb"
  default["clamav"]["scan_config"]["prod"] = "6_clamd_dev.conf.erb"
  default["clamav"]["script"]["dev"] = "6_clamd_scan_script_dev.erb"
  default["clamav"]["script"]["prod"] = "6_clamd_scan_script_prod.erb"
  default["clamav"]["service"]["script"] = "6_clamd_init.erb"
  default["clamav"]["scan"]["conf_location"] = "/etc/clamd.conf"
else
  default["clamav"]["scan_config"]["dev"] = "#{node['platform_version'].to_i}_scan_dev.conf.erb"
  default["clamav"]["scan_config"]["prod"] = "#{node['platform_version'].to_i}_scan_prod.conf.erb"
  default["clamav"]["script"]["dev"] = "78_clamd_scan_script_dev.erb"
  default["clamav"]["script"]["prod"] = "78_clamd_scan_script_prod.erb"
  default["clamav"]["scan"]["conf_location"] = "/etc/clamd.d/scan.conf"
end

# CLAMD_SCAN SCRIPT, START-CLAMAVSERVICE SHELL SCRIPT LOCATION WITH TEMPLATES INFO
default["clamav"]["scan_script_loc"]["dev"] = "/usr/bin/clamd_scan"
default["clamav"]["start_cron_loc"]["dev"] = "/usr/bin/start-clamavservice.sh"
default["clamav"]["scan_script_loc"]["prod"] = "/usr/bin/clamd_scan"
default["clamav"]["start_cron_loc"]["prod"] = "/usr/bin/start-clamavservice.sh"
default["clamav"]["start_cron"]["dev"] = "start-clamavservice_dev.erb"
default["clamav"]["start_cron"]["prod"] = "start-clamavservice_prod.erb"

# REMOVAL OF UNWANTED FILES FOR CLAMAV TO CONFIGURE
default["clamav"]["remove_files"] = ['/etc/cron.d/ee_clamav','/etc/cron.d/eis_clamav','/etc/cron.d/clamav-update','/etc/cron.daily/freshclam','/etc/logrotate.d/eis_clamav','/etc/logrotate.d/clamav-update','/etc/logrotate.d/freshclam','/etc/logrotate.d/clamav', '/usr/local/clamd_scan', '/usr/local/start-clamavservice.sh', '/usr/local/clamd_scanner_cron','/usr/local/weekly_clamd_scan','/usr/local/bin/weekly_clamd_scan','/usr/local/bin/clamd_scan', '/usr/local/bin/start-clamavservice.sh', '/usr/local/bin/clamd_scanner_cron']

# CPU LIMITS TEMPLATE, EXCLUSIONS FOR COLO AND ENGINEERING
if region == 'colo' || region == 'colo_dr'
  default["clamav"]["colo_exclusions"]=["ExcludePath ^/etc/suricata/rules/", "ExcludePath ^/var/lib/suricata/update/cache/", "ExcludePath ^/bkup/"]
  default["clamav"]["cpulimits_78"] = "override.conf.erb"
else
  default["clamav"]["cpulimits_78"] = "noncolo_override.conf.erb"
  default["clamav"]["colo_exclusions"]=[]
end

# ONACCESS SCANNING INCLUSION LIST
default["clamav"]["onaccess_include"]["dev"] = ["/boot","/var","/opt","/root","/scratch","/tmp","/usr","/etc"]
if node['platform_version'].to_i >= 6
  if oem_dir_check.chomp.to_i == 0
    default["clamav"]["onaccess_include"]["dev"].append("/oem")
  end
end

# ONACCESS EXCLUSION LIST
default["clamav"]["onaccess_exclude"]["dev"] = ["/usr/local","/boot/efi","/ade_autofs","/sys","/dev","/net","/proc","/var/lib","/var/run","/usr/lib","/usr/lib64","/usr/libexec","/bin","/sbin","/usr/bin","/usr/sbin","/usmmnt1 ","/usmmnt2","/usmmnt3","/usmmnt4","/usmmnt5","/usmmnt6","/usmmnt7","/usmmnt8","/usmmnt9","/usmmnt","/tkfv_mounts"]

# FULL SCAN EXCLUSION LIST
default["clamav"]["exclude"]["dev"] = ["/usr/local","/boot/efi","/ade_autofs","/sys","/dev","/net","/proc","/var/lib","/var/run"]
default["clamav"]["exclude"]["prod"] = ["/boot/efi","/sys","/dev","/net","/proc","/var/lib","/var/run"]

# ONLY FOR FARM ENVIRONMENT
if File.exists?("/root/.clamav_exceptions")
  if not File.zero?("/root/.clamav_exceptions")
    contents=File.readlines("/root/.clamav_exceptions") 
    contents.each do |line|  
      if not line.strip.empty?
        if default["clamav"]["onaccess_include"]["dev"].include? line.strip
          default["clamav"]["onaccess_include"]["dev"].delete(line.strip)
        end
        if not default["clamav"]["onaccess_exclude"]["dev"].include? line.strip
          default["clamav"]["onaccess_exclude"]["dev"].append(line.strip)
        end
      end
    end
  end
end

# OPTION TO SET TIME FOR CLAMAV SCAN 
if File.exists?("/root/.clamav_cron_schedule_time")
  if not File.zero?("/root/.clamav_cron_schedule_time")
    contents=File.read("/root/.clamav_cron_schedule_time")
      if not contents.strip.empty?
          time_str = contents.split(":")
          default['hour'] = time_str[0].strip
          default['minute'] = time_str[1].strip
      else
          default['hour'] = '0'
          default['minute'] = '0'
      end
  else
      default['hour'] = '0'
      default['minute'] = '0'
  end
else
   default['hour'] = '0'
   default['minute'] = '0'
end
