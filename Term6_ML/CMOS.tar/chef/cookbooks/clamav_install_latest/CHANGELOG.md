# clamav_install_latest CHANGELOG

This file is used to list changes made in each version of the clamav_install_latest cookbook.

## 0.1.0
- ORCL_CM_v1.1.0 [Channapragada Pavan Kumar] - OITBD 9839 - Modify clamav latest install engineering cookbook to change the baseurl path as well as fix the Peer certificate issue

- - -
Check the [Markdown Syntax Guide](http://daringfireball.net/projects/markdown/syntax) for help with Markdown.

The [Github Flavored Markdown page](http://github.github.com/github-flavored-markdown/) describes the differences between markdown on github and standard markdown.
