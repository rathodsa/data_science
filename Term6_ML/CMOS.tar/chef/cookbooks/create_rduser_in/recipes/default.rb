#
# Cookbook:: create_rduser_in
# Recipe:: default
#
# Copyright:: 2021, The Authors, All Rights Reserved.
#
###############################################################
# including the General_Lib_Functions to get the LOB of Server
################################################################
include_recipe 'General_Lib_Functions'

mfetpd_exitstatus = `service mfetpd status;echo $?`

user_check=`getent passwd rduser;echo $?`

if node['platform'] == 'oracle' &&  node['platform_version'].to_i >= 6

  ###STOP MCAFEE SERVICE IF EXIST
  if mfetpd_exitstatus.to_i == 0
    service "mfetpd" do
      action :stop
    end
  end

  ###CREATING A RDUSER_IN USER
  if user_check.chomp.to_i != 0
    execute 'create rduser user' do
      command 'useradd rduser -u 1544244;chage -E -1 -I -1 -m -1 -M -1 -W -1 rduser'
      not_if 'getent passwd rduser'
    end
  end 

  ###INSERT SECSCAN USER TO /ETC/PASSWD FILE
  if user_check.chomp.to_i == 0
    rduser_inuser_p = node['rduser_in_user'].to_s.strip()
    puts "#{rduser_inuser_p}"
    pass_c = `grep -i ^rduser /etc/passwd |wc -l`.chomp
    ldap_c = `egrep -iw 'ldap|sss' /etc/nsswitch.conf |wc -l`.chomp
    ruby_block 'Adding rduser user entry to passwd file' do
      block do
          fe = Chef::Util::FileEdit.new('/etc/passwd')
          fe.insert_line_after_match(/^sshd/, "#{rduser_inuser_p}")
          fe.write_file
      end
      only_if { ::File.exist?('/etc/passwd') && pass_c.to_i < 1 && ldap_c.to_i >= 1 }
    end    
  end

  #Create home directory
  directory '/home/rduser/.ssh' do
    owner 'rduser'
    mode '0700'
    recursive true
    action :create 
  end

  execute 'Change user attributes' do
    command 'chage -E -1 -I -1 -m -1 -M -1 -W -1 rduser'
  end
 
  cookbook_file '/home/rduser/.ssh/authorized_keys' do
    source 'authorized_keys'
    owner 'rduser'
    mode 0600
  end

  cookbook_file '/etc/sudoers.d/91-rduser' do
    source '91-rduser'
    owner 'root'
    group 'root'
    mode 0440
  end
   
  ###START THE MCAFEE IF EXIST
  if mfetpd_exitstatus.to_i == 3 || mfetpd_exitstatus.to_i == 0
    service "mfetpd" do
      action :start
    end
  end

else
  Chef::Log.info('UNSUPPORTED PLATFORM')
end
