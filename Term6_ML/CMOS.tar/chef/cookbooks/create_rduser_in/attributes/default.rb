default['rduser_in_user'] = 'rduser:x:1544244:999:BDS User:/home/rduser:/bin/bash'
