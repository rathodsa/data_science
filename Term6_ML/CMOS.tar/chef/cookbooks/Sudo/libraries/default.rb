require 'chef/mixin/shell_out'
include Chef::Mixin::ShellOut

# Module to get the SudoConfiguration details
module SudoConfigiuration
  # Function to get ldap url
  def self.ldapget
    if File.exist?('/etc/sssd/sssd.conf')
      ldap_su = shell_out("egrep '^ldap_uri|^ldap_backup_uri' /etc/sssd/sssd.conf | awk -F'=' '{print $2}'|xargs| sed 's/,/ /g'")
    else
      ldap_su = shell_out("grep -i '^URI' /etc/openldap/ldap.conf | sed 's/^uri//gI'")
    end
    return ldap_su.stdout.chomp
  end
  # Function to get whether sssd configured or not
  def self.ldapauth
    check_ldap_su = shell_out("cat /etc/sysconfig/authconfig|grep -i USELDAP=yes >/dev/null;echo $?")
    check_enldap_su = shell_out("cat /etc/sysconfig/authconfig|grep -i USELDAPAUTH=yes >/dev/null;echo $?")
    check_sssd_su = shell_out("cat /etc/sysconfig/authconfig|grep -i sssd=yes >/dev/null;echo $?")
    if check_ldap_su.stdout.to_i == 0 or check_enldap_su.stdout.to_i == 0 or check_sssd_su.stdout.to_i == 0
      return 0
    else
      return 1
    end
  end
end
