default['cacerts_dir'] = '/etc/openldap/cacerts'
default['cacerts_file'] = 'oracle_internal_corp.pem'
