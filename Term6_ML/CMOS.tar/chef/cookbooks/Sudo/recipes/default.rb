#
# Cookbook Name:: Sudo
# Recipe:: default
#
# Copyright 2021, ORACLE
# Author:: naga.sai.vosetti@oracle.com
# All rights reserved - Do Not Redistribute
#
##################################
## Global Variables declaration ##
##################################
#################################################
## Updating & configuring Sudo on Oracle Linux ##
#################################################

if node['platform'] == 'oracle' && (node['platform_version'].to_i  >= 6 || node['platform_version'].to_i == 3) && SudoConfigiuration.ldapauth == 0
  directory "#{node['cacerts_dir']}" do
    owner 'root'
    group 'root'
    mode '0755'
    action :create
  end
  cookbook_file "#{node['cacerts_dir']}/#{node['cacerts_file']}" do
    source "#{node['cacerts_file']}"
    owner 'root'
    group 'root'
    mode '644'
    action :create
  end
  template '/etc/sudo-ldap.conf' do
    source 'sudo-ldap.conf.erb'
    owner 'root'
    group 'root'
    mode '0600'
    variables(
      lazy do
        { ldap_uris: SudoConfigiuration.ldapget}
      end
    )
  end
  ruby_block "insert_line" do
    block do
      file = Chef::Util::FileEdit.new("/etc/nsswitch.conf")
      file.search_file_replace_line("^sudoers", "sudoers: ldap files")
      file.write_file
    end
    only_if  { `cat /etc/nsswitch.conf | grep '^sudoers'|wc -l`.to_i != 0 }
  end
  ruby_block "insert_line" do
    block do
      file = Chef::Util::FileEdit.new("/etc/nsswitch.conf")
      file.insert_line_if_no_match("^sudoers", "sudoers: ldap files")
      file.write_file
    end
    only_if { `cat /etc/nsswitch.conf | grep '^sudoers'|wc -l`.to_i == 0 }
  end  
else
  ruby_block 'OS is not supported' do
    block do
      Chef::Log.info('OS is not supported or configuration is not supported')
    end
  end
end
