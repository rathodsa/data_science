default['secscan_user'] = 'secscan:x:1985:10:mahesh.mudkhedkar@oracle.com:/home/secscan:/bin/bash'
if GeneralLibs::VmFunctions.oci_realmkey.nil?
  realmkey_info = ''
else
  realmkey_info = GeneralLibs::VmFunctions.oci_realmkey.chomp
end
region = `curl -m 5 -s -L http://169.254.169.254/opc/v1/instance/canonicalRegionName`.chomp

case realmkey_info
when "oc2","oc3"
   default['ca_pub_url'] = "https://castiel.#{region}.oci.oraclegoviaas.com/api/v1/user/keys.pub"
else
   default['ca_pub_url'] = "https://castiel.#{region}.oci.oracleiaas.com/api/v1/user/keys.pub"
end
