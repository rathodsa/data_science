#
# Cookbook:: security-bar
# Recipe:: default
#
# Copyright:: 2021, The Authors, All Rights Reserved.
#
###############################################################
# including the General_Lib_Functions to get the LOB of Server
################################################################
include_recipe 'General_Lib_Functions'
instance_type = GeneralLibs::VmFunctions.check_oci_or_not

mfetpd_exitstatus = `service mfetpd status;echo $?`
region = `curl -m 5 -s -L http://169.254.169.254/opc/v1/instance/canonicalRegionName`.chomp

user_check=`getent passwd secscan;echo $?`

if node['platform'] == 'oracle' &&  node['platform_version'].to_i >= 6 && instance_type == 'OCI'

  ###STOP MCAFEE SERVICE IF EXIST
  if mfetpd_exitstatus.to_i == 0
    service "mfetpd" do
      action :stop
    end
  end


  ####ADDING TRUST KEYS TO SSHD CONFIG FILE
  execute 'Add TrustCAKeys in sshd' do
    command 'cp -pr /etc/ssh/sshd_config /etc/ssh/sshd_config.`date +"%Y%m%d-%H%M%S"`;echo "TrustedUserCAKeys /etc/ssh/ca.pub" >> /etc/ssh/sshd_config'
    notifies :run,'execute[reload sshd service]',:immediately
    not_if 'grep "TrustedUserCAKeys /etc/ssh/ca.pub" /etc/ssh/sshd_config'
  end

  execute 'reload sshd service' do
    if node['platform_version'].to_i > 6
      command '/bin/systemctl reload sshd.service'
    else
      command '/sbin/service sshd reload'
    end
    action :nothing
  end


  ###CREATING A SECSCAN USER
  if user_check.chomp.to_i != 0
    execute 'create secscan user' do
      command 'useradd secscan -u 1985 -g 10'
      not_if 'getent passwd secscan'
    end
  end 

  ###INSERT SECSCAN USER TO /ETC/PASSWD FILE
  if user_check.chomp.to_i == 0
    secscanuser_p = node['secscan_user'].to_s.strip()
    puts "#{secscanuser_p}"
    pass_c = `grep -i ^secscan /etc/passwd |wc -l`.chomp
    ldap_c = `egrep -iw 'ldap|sss' /etc/nsswitch.conf |wc -l`.chomp
    ruby_block 'Adding secscan user entry to passwd file' do
      block do
          fe = Chef::Util::FileEdit.new('/etc/passwd')
          fe.insert_line_after_match(/^sshd/, "#{secscanuser_p}")
          fe.write_file
      end
      only_if { ::File.exist?('/etc/passwd') && pass_c.to_i < 1 && ldap_c.to_i >= 1 }
    end    
  end

  ###SET SECSCAN USER TO NON-EXPIRY
  execute 'set secscan user to non-expiry' do
     command 'chage -E -1 -I -1 -m -1 -M -1 -W -1 secscan'
     ignore_failure true
  end

  ###INSERT SECSCAN USER TO /etc/security/access.conf
  execute 'Add secscan user to access.conf file' do
    command '/bin/sed -i \'/+ : root : ALL/ i\+ : secscan : ALL\' /etc/security/access.conf'
    not_if 'grep secscan /etc/security/access.conf' 
    only_if 'grep -v "^#" /etc/security/access.conf | grep "^+"'
  end

  ###START THE MCAFEE IF EXIST
  if mfetpd_exitstatus.to_i == 3 || mfetpd_exitstatus.to_i == 0
    service "mfetpd" do
      action :start
      ignore_failure true
    end
  end


  ###INSTALL JQ
  execute 'install jq command' do
    if node['platform_version'].to_i < 8
      command 'yum --enablerepo=ol?_addons install jq -y'
    else
      command 'dnf --enablerepo=ol?_appstream install jq -y'
    end
    ignore_failure true
    not_if 'rpm -ql jq'
  end

  ##VALIDATE URL
  execute 'validate url' do
    command "curl -k #{node['ca_pub_url']}"
  end

  ###INSERT THE KEY TO CA.PUB
  execute 'Push the key to /etc/ssh/ca.pub without jq command' do
    command " curl -k #{node['ca_pub_url']}  >  /etc/ssh/ca.pub"
  end

  ##SET THE PERMISSIONS FOR ca.pub
  execute 'set permissions for ca.pub file' do
    command 'chmod 644 /etc/ssh/ca.pub'
    ignore_failure true
  end

  ##SET THE CRON TO PULL LATEST KEYS
  template '/usr/local/security_bar_key' do
    source 'security_bar_key.erb'
    owner 'root'
    group 'root'
    mode '755'
    variables(url:"#{node['ca_pub_url']}")
  end

  cron_d 'security_bar_cron' do
    action :create
    predefined_value "@daily"
    user 'root'
    command '/usr/local/security_bar_key > /dev/null 2>&1'
  end

else
  Chef::Log.info('UNSUPPORTED PLATFORM')
end
