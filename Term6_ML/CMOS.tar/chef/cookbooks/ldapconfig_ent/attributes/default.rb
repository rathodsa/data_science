# CHECK IF SERVER IS OF HIPPA ENVIRONMENT
default['hippa_ck']=GeneralLibs::VmFunctions.hippadetails()

# CHECK IF COLO
vmdetails = GeneralLibs::VmFunctions.vminfo(node)
default['colo_ck'] = vmdetails[1]

# DECLARING LDAPCONFIG VALUES AS PER OS VERSION
default['ldapconfig']['config_ldapfiles'] = ['sssd.conf', 'nsswitch.conf', 'nscd.conf']
default['ldapconfig']['coloconfig_ldapfiles'] = ['sssd.conf', 'nsswitch.conf']
default['ldapconfig']['certfiles'] = ['Oracle_CA_bundle.crt', 'SLOG_Oracle_CA_bundle.crt']
default['ldapconfig']['shadow_add'] = "+@#{node['fqdn']}::0:0:0::::"
default['ldapconfig']['passwd_add'] = "+@#{node['fqdn']}::::::"
default['ldapconfig']['passwd'] = "/etc/passwd"
default['ldapconfig']['shadow'] = "/etc/shadow"
default['ldapconfig']['mvfiles'] = "/etc/openldap/ldap.conf"
default['ldapconfig']['ovm_disable'] = %w(ldap nslcd)
default['ldapconfig']['ol_disable'] = %w(ldap nslcd)
default['ldapconfig']['authfiles'] = ['password-auth-ac', 'system-auth-ac']
if node['hippa_ck'] == 'hippa'
  default['ldapconfig']['netgroup'] = ['+']
elsif GeneralLibs::VmFunctions.envconfig_name == 'GITCOMPUTE'
  default['ldapconfig']['netgroup'] = ['+@cea_oci_admin', '+@cea_oci_ops']
elsif GeneralLibs::VmFunctions.netgroup_details == 'none' or GeneralLibs::VmFunctions.netgroup_details == 'null_default_netgroup'
  default['ldapconfig']['netgroup'] = ['+@pe_appops','+@eis_infra_ops','+@eis_network_security']
else
  default['ldapconfig']['netgroup'] = GeneralLibs::VmFunctions.netgroup_details.split(',').map{|s| s.start_with?("+@") ? s : s.prepend("+@")}
end

# DECLARING LDAP URLS BASED ON REGIONS
vmdetails = GeneralLibs::VmFunctions.vminfo(node)
region = vmdetails[1]
instance_type = GeneralLibs::VmFunctions.check_oci_or_not
tenancy_name = GeneralLibs::VmFunctions.tenancy_name

if instance_type == 'OCI'
  if tenancy_name == 'devapp' && region == 'iad'
    default['ldapconfig']['devapp']['iad']['ldap_uri'] = 'ldaps://100.93.96.130:636'
    default['ldapconfig']['devapp']['iad']['ldap_backup_uri'] = 'ldaps://100.93.96.131:636'
  elsif tenancy_name == 'devapp' && region == 'phx'
    default['ldapconfig']['devapp']['phx']['ldap_uri'] = 'ldaps://100.95.96.130:636'
    default['ldapconfig']['devapp']['phx']['ldap_backup_uri'] = 'ldaps://100.95.96.131:636'
  elsif tenancy_name == 'espsocicorpnonprod' && region == 'iad'
    default['ldapconfig']['espsocicorpnonprod']['iad']['ldap_uri'] = 'ldaps://100.101.213.67:636'
  elsif tenancy_name == 'externalnonprod' && region == 'iad'
    default['ldapconfig']['externalnonprod']['iad']['ldap_uri'] = 'ldaps://100.112.0.254:636'
  elsif tenancy_name == 'externalprod' && region == 'phx'
    default['ldapconfig']['externalprod']['phx']['ldap_uri'] = 'ldaps://100.114.0.2:636'
    default['ldapconfig']['externalprod']['phx']['ldap_backup_uri'] = 'ldaps://100.114.0.3:636'
  elsif tenancy_name == 'internalnonprod' && region == 'iad'
    default['ldapconfig']['internalnonprod']['iad']['ldap_uri'] = 'ldaps://100.111.64.7:636'
    default['ldapconfig']['internalnonprod']['iad']['ldap_backup_uri'] = 'ldaps://100.111.64.8:636'
  elsif tenancy_name == 'internalprod' && region == 'phx'
    default['ldapconfig']['internalprod']['phx']['ldap_uri'] = 'ldaps://100.111.236.254:636'
  elsif tenancy_name == 'peappinternalprod' && region == 'phx'
    default['ldapconfig']['peappinternalprod']['phx']['ldap_uri'] = 'ldaps://144.25.18.243:636'
  elsif tenancy_name == 'pesharedservices' && region == 'iad'
    default['ldapconfig']['pesharedservices']['iad']['ldap_uri'] = 'ldaps://100.112.4.50:636'
    default['ldapconfig']['pesharedservices']['iad']['ldap_backup_uri'] = 'ldaps://100.112.4.51:636'
  elsif tenancy_name == 'pesharedservices' && region == 'phx'
    default['ldapconfig']['pesharedservices']['phx']['ldap_uri'] = 'ldaps://100.114.4.58:636'
  elsif tenancy_name == 'prodapp' && region == 'iad'
    default['ldapconfig']['prodapp']['iad']['ldap_uri'] = 'ldaps://100.112.192.130:636'
    default['ldapconfig']['prodapp']['iad']['ldap_backup_uri'] = 'ldaps://100.112.192.131:636'
  elsif tenancy_name == 'prodapp' && region == 'phx'
    default['ldapconfig']['prodapp']['phx']['ldap_uri'] = 'ldaps://100.114.192.136:636'
    default['ldapconfig']['prodapp']['phx']['ldap_backup_uri'] = 'ldaps://100.114.192.133:636'
  elsif tenancy_name == 'prodapp' && region == 'ap-tokyo-1'
    default['ldapconfig']['prodapp']['ap-tokyo-1']['ldap_uri'] = 'ldaps://100.70.160.130:636'
    default['ldapconfig']['prodapp']['ap-tokyo-1']['ldap_backup_uri'] = 'ldaps://100.70.160.131:636'
  elsif tenancy_name == 'prodapp' && region == 'lhr'
    default['ldapconfig']['prodapp']['lhr']['ldap_uri'] = 'ldaps://100.123.8.66:636'
    default['ldapconfig']['prodapp']['lhr']['ldap_backup_uri'] = 'ldaps://100.123.8.67:636'
  elsif tenancy_name == 'prodapp' && region == 'eu-frankfurt-1'
    default['ldapconfig']['prodapp']['eu-frankfurt-1']['ldap_uri'] = 'ldaps://100.123.8.66:636'
    default['ldapconfig']['prodapp']['eu-frankfurt-1']['ldap_backup_uri'] = 'ldaps://100.123.8.67:636'
  elsif tenancy_name == 'prodapp' && region == 'bom'
    default['ldapconfig']['prodapp']['bom']['ldap_uri'] = 'ldaps://100.70.160.130:636'
    default['ldapconfig']['prodapp']['bom']['ldap_backup_uri'] = 'ldaps://100.70.160.131:636'
  elsif tenancy_name == 'hsgbuhsz' && region == 'phx'
    default['ldapconfig']['hsgbuhsz']['phx']['ldap_uri'] = 'ldap://gtm-pdit-ldap.oracle.com'
    default['ldapconfig']['hsgbuhsz']['phx']['ldap_backup_uri'] = 'ldap://gtm-pdit-ldap.oracle.com'
  elsif tenancy_name == 'hsgbuhsz' && region == 'iad'
    default['ldapconfig']['hsgbuhsz']['iad']['ldap_uri'] = 'ldap://gtm-pdit-ldap.oracle.com'
    default['ldapconfig']['hsgbuhsz']['iad']['ldap_backup_uri'] = 'ldap://gtm-pdit-ldap.oracle.com'
  elsif tenancy_name == 'rgbudevint' && region == 'phx'
    default['ldapconfig']['rgbudevint']['phx']['ldap_uri'] = 'ldap://gtm-pdit-ldap.oracle.com'
    default['ldapconfig']['rgbudevint']['phx']['ldap_backup_uri'] = 'ldap://gtm-pdit-ldap.oracle.com'
  elsif tenancy_name == 'rgbudevint' && region == 'iad'
    default['ldapconfig']['rgbudevint']['iad']['ldap_uri'] = 'ldap://gtm-pdit-ldap.oracle.com'
    default['ldapconfig']['rgbudevint']['iad']['ldap_backup_uri'] = 'ldap://gtm-pdit-ldap.oracle.com'
  elsif tenancy_name == 'peo' && region == 'phx'
    default['ldapconfig']['peo']['phx']['ldap_uri'] = 'ldap://gtm-pdit-ldap.oracle.com'
    default['ldapconfig']['peo']['phx']['ldap_backup_uri'] = 'ldap://gtm-pdit-ldap.oracle.com'
  elsif tenancy_name == 'oragit' && region == 'iad'
    default['ldapconfig']['oragit']['iad']['ldap_uri'] = 'ldaps://100.112.192.130:636'
    default['ldapconfig']['oragit']['iad']['ldap_backup_uri'] = 'ldaps://100.112.192.131:636'
  elsif tenancy_name == 'oragit' && region == 'phx'
    default['ldapconfig']['oragit']['phx']['ldap_uri'] = 'ldaps://100.114.192.136:636'
    default['ldapconfig']['oragit']['phx']['ldap_backup_uri'] = 'ldaps://100.114.192.133:636'
  elsif tenancy_name == 'oragit' && region == 'eu-frankfurt-1'
    default['ldapconfig']['oragit']['eu-frankfurt-1']['ldap_uri'] = 'ldaps://100.123.8.66:636'
    default['ldapconfig']['oragit']['eu-frankfurt-1']['ldap_backup_uri'] = 'ldaps://100.123.8.67:636'
  elsif tenancy_name == 'oragit' && region == 'lhr'
    default['ldapconfig']['oragit']['lhr']['ldap_uri'] = 'ldaps://100.123.8.66:636'
    default['ldapconfig']['oragit']['lhr']['ldap_backup_uri'] = 'ldaps://100.123.8.67:636'
  elsif tenancy_name == 'oragit' && region == 'ap-tokyo-1'
    default['ldapconfig']['oragit']['ap-tokyo-1']['ldap_uri'] = 'ldaps://100.70.160.130:636'
    default['ldapconfig']['oragit']['ap-tokyo-1']['ldap_backup_uri'] = 'ldaps://100.70.160.131:636'
  elsif tenancy_name == 'oragit' && region == 'bom'
    default['ldapconfig']['oragit']['bom']['ldap_uri'] = 'ldaps://100.70.160.130:636'
    default['ldapconfig']['oragit']['bom']['ldap_backup_uri'] = 'ldaps://100.70.160.131:636'
  elsif tenancy_name == 'oragit2' && region == 'iad'
    default['ldapconfig']['oragit2']['iad']['ldap_uri'] = 'ldaps://100.112.192.130:636'
    default['ldapconfig']['oragit2']['iad']['ldap_backup_uri'] = 'ldaps://100.112.192.131:636'
  elsif tenancy_name == 'oragit2' && region == 'phx'
    default['ldapconfig']['oragit2']['phx']['ldap_uri'] = 'ldaps://100.114.192.136:636'
    default['ldapconfig']['oragit2']['phx']['ldap_backup_uri'] = 'ldaps://100.114.192.133:636'
  elsif tenancy_name == 'oragit2' && region == 'eu-frankfurt-1'
    default['ldapconfig']['oragit2']['eu-frankfurt-1']['ldap_uri'] = 'ldaps://100.123.8.66:636'
    default['ldapconfig']['oragit2']['eu-frankfurt-1']['ldap_backup_uri'] = 'ldaps://100.123.8.67:636'
  elsif tenancy_name == 'oragit2' && region == 'lhr'
    default['ldapconfig']['oragit2']['lhr']['ldap_uri'] = 'ldaps://100.123.8.66:636'
    default['ldapconfig']['oragit2']['lhr']['ldap_backup_uri'] = 'ldaps://100.123.8.67:636'
  elsif tenancy_name == 'oragit2' && region == 'ap-tokyo-1'
    default['ldapconfig']['oragit2']['ap-tokyo-1']['ldap_uri'] = 'ldaps://100.70.160.130:636'
    default['ldapconfig']['oragit2']['ap-tokyo-1']['ldap_backup_uri'] = 'ldaps://100.70.160.131:636'
  elsif tenancy_name == 'oragit2' && region == 'bom'
    default['ldapconfig']['oragit2']['bom']['ldap_uri'] = 'ldaps://100.70.160.130:636'
    default['ldapconfig']['oragit2']['bom']['ldap_backup_uri'] = 'ldaps://100.70.160.131:636'
  elsif tenancy_name == 'oragitd' && region == 'iad'
    default['ldapconfig']['oragitd']['iad']['ldap_uri'] = 'ldaps://100.112.192.130:636'
    default['ldapconfig']['oragitd']['iad']['ldap_backup_uri'] = 'ldaps://100.112.192.131:636'
  elsif tenancy_name == 'oragitd' && region == 'phx'
    default['ldapconfig']['oragitd']['phx']['ldap_uri'] = 'ldaps://100.114.192.136:636'
    default['ldapconfig']['oragitd']['phx']['ldap_backup_uri'] = 'ldaps://100.114.192.133:636'
  elsif tenancy_name == 'oragitd' && region == 'eu-frankfurt-1'
    default['ldapconfig']['oragitd']['eu-frankfurt-1']['ldap_uri'] = 'ldaps://100.123.8.66:636'
    default['ldapconfig']['oragitd']['eu-frankfurt-1']['ldap_backup_uri'] = 'ldaps://100.123.8.67:636'
  elsif tenancy_name == 'oragitd' && region == 'lhr'
    default['ldapconfig']['oragitd']['lhr']['ldap_uri'] = 'ldaps://100.123.8.66:636'
    default['ldapconfig']['oragitd']['lhr']['ldap_backup_uri'] = 'ldaps://100.123.8.67:636'
  elsif tenancy_name == 'oragitd' && region == 'ap-tokyo-1'
    default['ldapconfig']['oragitd']['ap-tokyo-1']['ldap_uri'] = 'ldaps://100.70.160.130:636'
    default['ldapconfig']['oragitd']['ap-tokyo-1']['ldap_backup_uri'] = 'ldaps://100.70.160.131:636'
  elsif tenancy_name == 'oragitd' && region == 'bom'
    default['ldapconfig']['oragitd']['bom']['ldap_uri'] = 'ldaps://100.70.160.130:636'
    default['ldapconfig']['oragitd']['bom']['ldap_backup_uri'] = 'ldaps://100.70.160.131:636'
  elsif tenancy_name == 'cmosusgovdod' && region == 'us-langley-1'
    default['ldapconfig']['cmosusgovdod']['us-langley-1']['ldap_uri'] = 'ldaps://cmosdseeldap.cmosdodlfi.oraclevcn.com:636'
  elsif tenancy_name == 'cmosusgovdod' && region == 'us-luke-1'
    default['ldapconfig']['cmosusgovdod']['us-luke-1']['ldap_uri'] = 'ldaps://cmosdseeldap.cmosdodlfi.oraclevcn.com:636'
  else
    Chef::Log.info('No Ldap servers defined')
  end
else
  if region == 'colo'
    default['ldapconfig']['colo']['ldap_uri'] = 'ldaps://gtm-pdit-ldap.oracle.com:636'
    default['ldapconfig']['colo']['ldap_backup_uri'] = 'ldaps://ucfpditldap.us.oracle.com:636'
  elsif region == 'colo_dr'
    default['ldapconfig']['colo_dr']['ldap_uri'] = 'ldaps://adcpditldap.us.oracle.com:636'
    default['ldapconfig']['colo_dr']['ldap_backup_uri'] = 'ldaps://ucfpditldap.us.oracle.com:636'
  else
    Chef::Log.info('Region not found')
  end
end
