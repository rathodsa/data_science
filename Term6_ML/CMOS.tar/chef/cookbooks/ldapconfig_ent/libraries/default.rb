require 'chef/mixin/shell_out'
include Chef::Mixin::ShellOut

# WRITING Authconfig MODULE TO GET LDAP/SSSD DETAILS
module Authconfig
  # FUNCTION TO CHECK SSSD STATUS
  def self.enablesssdauth(node)
    check_sssd = `cat /etc/sysconfig/authconfig|grep -i sssd=yes >/dev/null;echo $?`.chomp.to_i
    sss_module = `grep -i pam_sss.so /etc/pam.d/* |wc -l`.chomp.to_i
    ldap_module = `grep -i pam_ldap.so /etc/pam.d/* |wc -l`.chomp.to_i
    if (check_sssd != 0 || sss_module == 0 || ldap_module != 0) && node['lsb']['id'] == "OracleVMserver"
      out = shell_out('authconfig --updateall --enablesssd --enablesssdauth --disableldap --disableldapauth >/dev/null;echo $?')
      ensssd_status = out.stdout.chomp
      return ensssd_status.to_i
    elsif (check_sssd != 0 || sss_module == 0 || ldap_module != 0) && node['platform_version'].to_i >= 6
      if node['colo_ck'] == 'colo' || node['colo_ck'] == 'colo_dr'
        #out = shell_out('authconfig --enablesssd --disableldap --disableldapauth --diablefaillock --faillockargs "deny=4 unlock_time=1200" --nostart --update --updateall >/dev/null;echo $?')
        #ensssd_status = out.stdout.chomp
        #return ensssd_status.to_i
       return 0
      else
        out = shell_out('authconfig --enablepamaccess --enablesssd --enablesssdauth --disableldap --disableldapauth --enableldaptls --enablemkhomedir --enablefaillock --faillockargs "deny=3 unlock_time=1800 fail_interval=900"  --nostart --update --updateall >/dev/null;echo $?')
        ensssd_status = out.stdout.chomp
        return ensssd_status.to_i
      end
    else
      return 0
    end
  end
end

# FUNCTION TO CREATE TEMPLATE BY PASSING PARAMETERS BASED ON CONFIGURATION FILE
def ldap(con_file, ldap_uri, ldap_backup_uri)
  if con_file == 'sssd.conf'
    template "/etc/sssd/#{con_file}" do
      source "#{con_file}.erb"
      owner 'root'
      group 'root'
      mode '0600'
      variables(
        :primary => ldap_uri,
        :second => ldap_backup_uri
      )
      notifies :restart, 'service[sssd]'
    end
  elsif con_file == 'nsswitch.conf'
    template "/etc/#{con_file}" do
      source "#{con_file}.erb"
      owner 'root'
      group 'root'
      mode '0644'
    end
  else
    template "/etc/#{con_file}" do
      source "#{con_file}.erb"
      owner 'root'
      group 'root'
      mode '0644'
      variables(
        :primary => ldap_uri,
        :second => ldap_backup_uri
      )
    end
  end
end

# function to copy the template for ldap config
def ldap7(con_file, ldap_uri, ldap_backup_uri)
  if con_file == 'sssd.conf'
    template "/etc/sssd/#{con_file}" do
      if node['hippa_ck'] == 'hippa'
        source "hippa_#{con_file}7.erb"
      elsif node['colo_ck'] == 'colo' || node['colo_ck'] == 'colo_dr'
        source "colo_#{con_file}7.erb"
      else
        source "#{con_file}7.erb"
      end
      owner 'root'
      group 'root'
      mode '0600'
      variables(
        :primary => ldap_uri,
        :second => ldap_backup_uri
      )
      notifies :restart, 'service[sssd]'
    end
  elsif con_file == 'nsswitch.conf'
    template "/etc/#{con_file}" do
      if node['hippa_ck'] == 'hippa'
        source "hippa_#{con_file}7.erb"
      elsif node['colo_ck'] == 'colo' || node['colo_ck'] == 'colo_dr'
        source "colo_#{con_file}7.erb"
      else
        source "#{con_file}7.erb"
      end
      owner 'root'
      group 'root'
      mode '0644'
    end
  else
    template "/etc/#{con_file}" do
      if node['colo_ck'] == 'colo' || node['colo_ck'] == 'colo_dr'
        source "colo_#{con_file}7.erb"
      else
        source "#{con_file}.erb"
      end
      owner 'root'
      group 'root'
      mode '0644'
      variables(
        :primary => ldap_uri,
        :second => ldap_backup_uri
      )
    end
  end
end
