#
# Cookbook Name:: ldapconfig_ent
# Recipe:: default
# Author: naga.sai.vosetti@oracle.com
# Copyright 2021, ORACLE
#
# All rights reserved - Do Not Redistribute
#
include_recipe 'General_Lib_Functions'
vmdetails = GeneralLibs::VmFunctions.vminfo(node)
region = vmdetails[1]
tenancy_name = GeneralLibs::VmFunctions.tenancy_name

# checking if the os is Oracle linux or check OVM as well
if node['platform'] == 'oracle' and node['lsb']['id'] == "OracleVMserver"
  # creating repo, certs,pam,sssd directory and installing nscd and sssd package
  cookbook_file '/etc/yum.repos.d/ovm.repo' do
    source 'ovm.repo'
    owner 'root'
    group 'root'
    mode  '0644'
  end
  directory '/etc/openldap/cacerts/' do
    owner 'root'
    group 'root'
    mode  '0755'
    recursive true
    not_if { ::File.exist?('/etc/openldap/cacerts/') }
  end
  directory '/etc/pam.d/' do
    owner 'root'
    group 'root'
    mode '0755'
    recursive true
    not_if { ::File.exist?('/etc/pam.d/') }
  end
  directory '/etc/sssd/' do
    owner 'root'
    group 'root'
    mode  '0755'
    recursive true
    action :create
    not_if { ::File.exist?('/etc/sssd/') }
  end
    # copying the template for /etc/sssd/sssd.conf,/etc/nsswitch.conf and /etc/nscd.conf
    if Authconfig.enablesssdauth(node) == 0
      if region != ' '
        if region == 'colo' || region == 'colo_dr'
          node['ldapconfig']['config_ldapfiles'].each do |con_file|
            ldap(con_file.to_s, node['ldapconfig'][region.to_s]['ldap_uri'], node['ldapconfig'][region.to_s]['ldap_backup_uri'])
          end
        else
          node['ldapconfig']['config_ldapfiles'].each do |con_file|
            ldap(con_file.to_s, node['ldapconfig'][tenancy_name.to_s][region.to_s]['ldap_uri'], node['ldapconfig'][tenancy_name.to_s][region.to_s]['ldap_backup_uri'])
          end
        end
      else
        Chef::Log.info('Region not found')
      end
      # copying the ldap certification to /etc/openldap/cacerts location
      node['ldapconfig']['certfiles'].each do |cert|
        cookbook_file "/etc/openldap/cacerts/#{cert}" do
          source cert.to_s
          owner 'root'
          group 'root'
          mode '0644'
        end
      end
      # taking backup and moving ldap.conf file
      execute 'mv ldap config file' do
        command "mv  #{node['ldapconfig']['mvfiles']} #{node['ldapconfig']['mvfiles']}.orig"
        only_if { ::File.exist?("#{node['ldapconfig']['mvfiles']}") }
      end
      # adding "+@<fqdn>::::::" to /etc/passwd
      execute 'adding  + to config files' do
        command "echo #{node['ldapconfig']['passwd_add']} >> #{node['ldapconfig']['passwd']}"
        not_if "grep ^#{node['ldapconfig']['passwd_add']} #{node['ldapconfig']['passwd']}"
      end
      # adding "+@<fqdn>::0:0:0::::" to /etc/shadow
      execute 'adding  + to config files' do
        command "echo #{node['ldapconfig']['shadow_add']} >> #{node['ldapconfig']['shadow']}"
        not_if "grep ^#{node['ldapconfig']['shadow_add']} #{node['ldapconfig']['shadow']}"
      end
      # copying the pam files password-auth-ac & system-auth-ac
      node['ldapconfig']['authfiles'].each do |file|
      	cookbook_file "/etc/pam.d/#{file}" do
      	  source "#{file}"
      	  owner 'root'
      	  group 'root'
      	  mode '0644'
        end
      end
      # enabling and disalbing the the required services
      node['ldapconfig']['ovm_disable'].each do |ser|
        service ser.to_s do
          supports status: true
          action [:disable, :stop]
        end
      end
      service 'nscd' do
        action  [ :enable, :start]
        supports start: true, restart: true, status: true, reload: true
      end
      service 'sssd' do
        action  [ :enable, :start]
        supports start: true, restart: true, status: true, reload: true
      end
    else
      # ths block is for faield authconfig command to enable sssd
      Chef::Log.info('Authconfig command faield to enable sssd')
    end
  # deleting the create repo file
  file '/etc/yum.repos.d/ovm.repo' do
    action :delete
  end
elsif node['platform'] == 'oracle' and node['platform_version'].to_i >= 6
  directory '/etc/openldap/cacerts/' do
    owner 'root'
    group 'root'
    mode  '0755'
    recursive true
    not_if { ::File.exist?('/etc/openldap/cacerts/') }
  end
  directory '/etc/pam.d/' do
    owner 'root'
    group 'root'
    mode '0755'
    recursive true
    not_if { ::File.exist?('/etc/pam.d/') }
  end
  package %w(nscd sssd sssd-proxy) do
    action :install
    flush_cache [:before]
  end
  directory '/etc/sssd/' do
    owner 'root'
    group 'root'
    mode  '0755'
    recursive true
    action :create
    not_if { ::File.exist?('/etc/sssd/') }
  end
  if Authconfig.enablesssdauth(node) == 0
    if region != ' '
      if region == 'colo' || region == 'colo_dr'
        node['ldapconfig']['coloconfig_ldapfiles'].each do |con_file|
          ldap7(con_file.to_s, node['ldapconfig'][region.to_s]['ldap_uri'], node['ldapconfig'][region.to_s]['ldap_backup_uri'])
        end
      else
        node['ldapconfig']['config_ldapfiles'].each do |con_file|
          ldap7(con_file.to_s, node['ldapconfig'][tenancy_name.to_s][region.to_s]['ldap_uri'], node['ldapconfig'][tenancy_name.to_s][region.to_s]['ldap_backup_uri'])
        end
      end
    else
      Chef::Log.info('Region not found')
    end
    # copying the ldap certification to /etc/openldap/cacerts location
    node['ldapconfig']['certfiles'].each do |cert|
      cookbook_file "/etc/openldap/cacerts/#{cert}" do
        source cert.to_s
        owner 'root'
        group 'root'
        mode '0644'
      end
    end
    if region == 'colo' || region == 'colo_dr'
      # taking backup and moving ldap.conf file
      execute 'mv ldap config file' do
        command "mv  #{node['ldapconfig']['mvfiles']} #{node['ldapconfig']['mvfiles']}.orig"
        only_if { ::File.exist?("#{node['ldapconfig']['mvfiles']}") }
      end
      # adding "+@<fqdn>::::::" to /etc/passwd
      execute 'adding  + to config files' do
        command "echo #{node['ldapconfig']['passwd_add']} >> #{node['ldapconfig']['passwd']}"
        not_if "grep ^#{node['ldapconfig']['passwd_add']} #{node['ldapconfig']['passwd']}"
      end
      # copying the pam files password-auth-ac & system-auth-ac
      node['ldapconfig']['authfiles'].each do |file|
        cookbook_file "/etc/pam.d/#{file}" do
          source "#{file}7"
          owner 'root'
          group 'root'
          mode '0644'
        end
      end
    else
      # adding netgroup to /etc/passwd
      node['ldapconfig']['netgroup'].each do |netgr|
        execute 'adding netgroup  to config files' do
          command "echo #{netgr} >> #{node['ldapconfig']['passwd']}"
          not_if "grep ^#{netgr} #{node['ldapconfig']['passwd']}"
        end
      end
    end
    # enabling and disalbing the the required services
    node['ldapconfig']['ol_disable'].each do |ser|
      service ser.to_s do
        supports status: true
        action [:disable, :stop]
      end
    end
    service 'nscd' do
      action  [ :enable, :start]
      supports start: true, restart: true, status: true, reload: true
    end
    service 'sssd' do
      action  [ :enable, :start]
      supports start: true, restart: true, status: true, reload: true
    end
    if node['platform_version'].to_i >= 8
      service 'oddjobd' do
        action  [ :enable, :start]
        supports start: true, restart: true, status: true, reload: true
      end
    end
  else
    # ths block is for faield authconfig command to enable sssd
    Chef::Log.info('Authconfig command faield to enable sssd')
  end
else
  # this block for wrong os version
  Chef::Log.info('Wrong os version')
end
