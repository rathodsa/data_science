def rsyslog_update(rsyslogserver)
  #rsyslog_cfg = node['rsyslog_conf'].to_s.strip()
  template '/etc/rsyslog.conf' do
    source node['rsyslog_conf'] 
    cookbook 'rsyslog'
    owner 'root'
    group 'root'
    mode '0644'
    variables(:siemserver => rsyslogserver)
  end
end
