#
# Cookbook Name:: rsyslog
# Recipe:: default
#
# Copyright 2018, ORACLE
# Author:: anilkumar.kv@oracle.com
# All rights reserved - Do Not Redistribute
#
####################################
### Global Variables declaration ###
####################################
include_recipe 'General_Lib_Functions'
instance_type = GeneralLibs::VmFunctions.check_oci_or_not
region_emagent = GeneralLibs::VmFunctions.vminfo(node)
region = region_emagent[1]
rsyslog_tenancy = GeneralLibs::VmFunctions.tenancy_name
os_ver = node['platform_version'].to_i
#############################################################
## rsyslog configuration for HIPPA (Oracle Linux machines) ##
#############################################################

if rsyslog_tenancy == '' || rsyslog_tenancy == 'none' || rsyslog_tenancy == 'None'
   rsyslog_tenancy = 'tenancy_default'
end

if instance_type == 'OCI' && node['platform'] == 'oracle'
   rsyslog_update(node['rsyslog_server'][rsyslog_tenancy.to_s][region.to_s])
else
   rsyslog_update(node['rsyslog_region']['allregion'])
end

if node['platform_version'].to_i == 5
  service 'syslog' do
   supports :start => true, :stop => true, :restart => true, :status => true
   action [:disable, :stop]
  end
end

service 'rsyslog' do
  supports :start => true, :stop => true, :restart => true, :status => true
  action [:enable, :start]
end
