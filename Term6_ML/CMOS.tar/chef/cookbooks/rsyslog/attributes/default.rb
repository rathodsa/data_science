# All the Enable/Disable services listed here in the form of array

vmdetails = GeneralLibs::VmFunctions.vminfo(node)
instance_type = GeneralLibs::VmFunctions.check_oci_or_not
region = vmdetails[1]
hippa_ck = GeneralLibs::VmFunctions.hippadetails()

if instance_type == 'OCI'
  default['rsyslog_server']['devapp']['iad'] = ['iaddalogprin01.comsiiad.devappiadsiv1.oraclevcn.com']
  default['rsyslog_server']['devapp']['phx'] = ['phxdalogprin01.comsiphx.devappphxsiv1.oraclevcn.com']
  default['rsyslog_server']['externalnonprod']['phx'] = ['iadenlognpin01.syslogssiad.externalnpssiad.oraclevcn.com']
  default['rsyslog_server']['externalnonprod']['iad'] = ['iadenlognpin01.syslogssiad.externalnpssiad.oraclevcn.com']
  default['rsyslog_server']['internalnonprod']['phx'] = ['iadinlognpin01.syslogssiad.internalnonpiad.oraclevcn.com']
  default['rsyslog_server']['internalnonprod']['iad'] = ['iadinlognpin01.syslogssiad.internalnonpiad.oraclevcn.com']
  default['rsyslog_server']['prodapp']['phx'] = ['phxpalogprin01.comsiphx.prodappphxsiv1.oraclevcn.com']
  default['rsyslog_server']['prodapp']['iad'] = ['iadpalogprin01.comsiiad.prodappiadsiv1.oraclevcn.com']
  default['rsyslog_server']['prodapp']['lhr'] = ['frapalogprin01.comsifra.prodappfrasiv1.oraclevcn.com']
  default['rsyslog_server']['prodapp']['eu-frankfurt-1'] = ['frapalogprin01.comsifra.prodappfrasiv1.oraclevcn.com']
  default['rsyslog_server']['prodapp']['ap-tokyo-1'] = ['bompalogprin01.comsibom.prodappbomsiv1.oraclevcn.com']
  default['rsyslog_server']['prodapp']['bom'] = ['bompalogprin01.comsibom.prodappbomsiv1.oraclevcn.com']
  default['rsyslog_server']['pesharedservices']['iad'] = ['iadpslogprin01.sgdsyslogiad.pesharedseriad.oraclevcn.com']
  default['rsyslog_server']['pesharedservices']['phx'] = ['phxpslogprin01.sgdsyslogphx.pesharedserphx.oraclevcn.com']
  default['rsyslog_server']['espsocicorpnonprod']['iad'] = ['pesyslogrlypoc1.syslogssiad.espsnonpiad.oraclevcn.com']
  default['rsyslog_server']['peappinternalprod']['phx'] = ['phxaplogprin01.syslogssphx.peappintprodphx.oraclevcn.com']
  default['rsyslog_server']['externalprod']['phx'] = ['phxeplogprin01.syslogssphx.externalpssphx.oraclevcn.com']
  default['rsyslog_server']['internalprod']['phx'] = ['phxiplogprin01.syslogssphx.internalpssphx.oraclevcn.com']
  default['rsyslog_server']['tenancy_default']['phx'] = ['10.153.162.8','144.20.92.36']
  default['rsyslog_server']['tenancy_default']['iad'] = ['10.153.162.8','144.20.92.36']
  default['rsyslog_server']['tenancy_default']['lhr'] = ['10.153.162.8','144.20.92.36']
  default['rsyslog_server']['tenancy_default']['bom'] = ['10.153.162.8','144.20.92.36']
  default['rsyslog_server']['hsgbuhsz']['phx'] = ['10.153.162.8','144.20.92.36']
  default['rsyslog_server']['hsgbuhsz']['iad'] = ['10.153.162.8','144.20.92.36']
  default['rsyslog_server']['rgbudevint']['phx'] = ['10.153.162.8','144.20.92.36']
  default['rsyslog_server']['rgbudevint']['iad'] = ['10.153.162.8','144.20.92.36']
  default['rsyslog_server']['peo']['phx'] = ['10.153.162.8','144.20.92.36'] 
  default['rsyslog_server']['peocorpprod']['phx'] = ['phxpclogprin01.logrelaydsiphx.peocorpphxssv1.oraclevcn.com']
  default['rsyslog_server']['peocorpprod']['iad'] = ['iadpclogprin01.logrelaydsiiad.peocorpiadssv1.oraclevcn.com']
  default['rsyslog_server']['peocorpprod']['lhr'] = ['lhrpclogprin01.logrelaydsilhr.peocorplhrssv1.oraclevcn.com']
  default['rsyslog_server']['peocorpprod']['bom'] = ['bompclogprin01.logrelaydsibom.peocorpbomssv1.oraclevcn.com']
  default['rsyslog_server']['cmosusgovdod']['us-langley-1'] = ['lfigovlogprin01.syslogmtpd1.cmosdodlfisiv1.oraclevcn.com']

else 
  if region == 'colo' || region == 'colo_dr'
    default['rsyslog_region']['allregion'] = ['adc-sim-mgr1.us.oracle.com','brmdc-siem-mgr1.us.oracle.com']
  else
    default['rsyslog_region']['allregion'] = ['144.20.92.36', '10.153.162.8']
  end
end 

if hippa_ck == 'hippa'            
  default['rsyslog_conf'] = 'rsyslog.confhippa.erb'
elsif region == 'colo' || region == 'colo_dr'
  default['rsyslog_conf'] = 'rsyslog.confcolo.erb'
else                        
  case node['platform_version'].to_i
  when 5, 6
     default['rsyslog_conf'] = 'rsyslog.conf6.erb'
  when 7
     default['rsyslog_conf'] = 'rsyslog.conf7.erb'
  when 8
     default['rsyslog_conf'] = 'rsyslog.conf8.erb'
  when 9
     default['rsyslog_conf'] = 'rsyslog.conf9.erb'
  end
end
