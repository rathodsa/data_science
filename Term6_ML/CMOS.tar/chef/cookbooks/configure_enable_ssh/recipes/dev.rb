#
# Cookbook Name:: configure_enable_ssh
# Recipe:: dev
#
# Copyright 2017, ORACLE
#
# All rights reserved - Do Not Redistribute
# Author :  jagannadham.mahanti@oracle.com
#
region_emagent = GeneralLibs::VmFunctions.vminfo(node)
hostsecvalue=`crontab -l | grep '.hostsec' 1>/dev/null; echo $?`
if node['platform'] == 'oracle' || node['platform'] == 'ubuntu' || node['platform'] == 'debian'
  # Using template resource to create a ssh config file
  template '/etc/ssh/sshd_config' do
    source "#{node['source_hostsec_sshd']}"
    owner 'root'
    mode 0600
    notifies :restart, 'service[sshd]'
    only_if {  hostsecvalue.chomp.to_i == 0  }
  end
  template '/etc/ssh/ssh_config' do
    source "#{node['source_hostsec_ssh']}"
    owner 'root'
    mode 0644
    notifies :restart, 'service[sshd]'
    only_if { hostsecvalue.chomp.to_i == 0 }
  end

  template '/etc/ssh/sshd_config' do
    source "#{node['source_sshd']}"
    owner 'root'
    mode 0600
    notifies :restart, 'service[sshd]'
    not_if { hostsecvalue.chomp.to_i == 0 }
  end
  template '/etc/ssh/ssh_config' do
    source "#{node['source_ssh']}"
    owner 'root'
    mode 0644
    notifies :restart, 'service[sshd]'
    not_if { hostsecvalue.chomp.to_i == 0 }
  end
  if node['platform_version'].to_i == 6
    node['dsa_key'].each do |pkg|
      file "#{pkg}" do
        action :delete
      end
    end
    template '/etc/sysconfig/sshd' do
      source 'sysconfig_sshd.erb'
      owner 'root'
      mode 0640
      notifies :restart, 'service[sshd]'
    end
  end

  # Using service resource to enable sshd service
  service 'sshd' do
    supports :start => true, :restart => true, :status => true, :reload => true
    action [:enable, :start]
  end
else
  Chef::Log.info('UNSUPPORTED PLATFORM')
end

if region_emagent[0] == 'prod'
  template '/etc/ssh_banner' do
    source "#{node['banner_ssh']}"
    owner 'root'
    mode 0644
    notifies :restart, 'service[sshd]'
  end
end
