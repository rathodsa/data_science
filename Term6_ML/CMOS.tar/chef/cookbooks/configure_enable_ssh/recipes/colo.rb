#
# Cookbook Name:: configure_enable_ssh
# Recipe:: default
#
# Copyright 2021, ORACLE
# Author:: naga.sai.vosetti@oracle.com
# All rights reserved - Do Not Redistribute
#
##################################
## Global Variables declaration ##
##################################
#################################################
## Updating & configuring fact_gathering on Oracle Linux ##
#################################################

if node['platform'] == 'oracle'
  # Using template resource to create a ssh config file
  template '/etc/ssh/sshd_config' do
    source "#{node['source_sshd_colo']}"
    owner 'root'
    mode 0600
    notifies :restart, 'service[sshd]'
  end
  service 'sshd' do
    action  [ :enable, :start]
    supports start: true, restart: true, status: true, reload: true
  end
else
  ruby_block 'OS is not supported' do
    block do
      Chef::Log.info('OS is not supported')
    end
  end
end
