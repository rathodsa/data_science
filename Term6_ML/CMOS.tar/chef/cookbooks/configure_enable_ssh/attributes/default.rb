region_emagent = GeneralLibs::VmFunctions.vminfo(node)
hippa_ck = GeneralLibs::VmFunctions.hippadetails()
region = GeneralLibs::VmFunctions.vminfo(node)[1]
if GeneralLibs::VmFunctions.oci_realmkey.nil?
  realmkey_info = ''
else
  realmkey_info = GeneralLibs::VmFunctions.oci_realmkey.chomp
end
if hippa_ck == 'hippa'
  default['banner_ssh'] = 'ssh_banner_hippa.erb'
else
  default['banner_ssh'] = 'ssh_banner.erb'
end
if region == 'colo' || region == 'colo_dr'
  if node['platform'] == 'oracle'
    case node['platform_version'].to_i
    when 3
      default['source_sshd_colo'] = 'sshd_colo.erb'
    when 6
      default['source_sshd_colo'] = 'sshd_colo.erb'
    else
      default['source_sshd_colo'] = 'sshd_colo7.erb'
    end
  end
end
default['dsa_key'] = ['/etc/ssh/ssh_host_dsa_key','/etc/ssh/ssh_host_dsa_key.pub']

if node['platform'] == 'oracle'
  case node['platform_version'].to_i
  when 3
    default['source_sshd'] = 'sshd_ol344.erb'
    default['source_ssh'] = 'ssh_ol344.erb'
  when 5
    default['source_sshd'] = 'sshd_ol5.erb'
    default['source_ssh'] = 'ssh_ol5.erb'
    default['source_hostsec_sshd'] = 'sshd_hostsec_ol5.erb'
    default['source_hostsec_ssh'] = 'ssh_hostsec_ol5.erb'
  when 6
    if(File.exist?('/root/.bst'))
      default['source_sshd_ent'] = 'sshd_entbst_ol6.erb'
    elsif(File.exist?('/root/.bst-port'))
      default['source_sshd_ent'] = 'sshd_entbstprt_ol6.erb'
    else
      default['source_sshd_ent'] = 'sshd_ent_ol6.erb'
    end
    default['source_sshd_entdb'] = 'sshd_entdb_ol6.erb'
    if region_emagent[0] == 'prod'
      default['source_sshd'] = 'sshd_prod_ol6.erb'
      default['source_ssh'] = 'ssh_ol6.erb'
      default['source_hostsec_sshd'] = 'sshd_hostsec_ol6.erb'
      default['source_hostsec_ssh'] = 'ssh_hostsec_ol6.erb'
    else
      default['source_sshd'] = 'sshd_ol6.erb'
      default['source_ssh'] = 'ssh_ol6.erb'
      default['source_hostsec_sshd'] = 'sshd_hostsec_ol6.erb'
      default['source_hostsec_ssh'] = 'ssh_hostsec_ol6.erb'
    end
  when 7
    if(File.exist?('/root/.bst'))
      default['source_sshd_ent'] = 'sshd_entbst_ol7.erb'
    elsif(File.exist?('/root/.bst-port'))
      default['source_sshd_ent'] = 'sshd_entbstprt_ol7.erb'
    elsif realmkey_info == 'oc2'
      default['source_sshd_ent'] = 'sshd_oc2_ol7.erb'
    else
      default['source_sshd_ent'] = 'sshd_ent_ol7.erb'
    end
    default['source_sshd_entdb'] = 'sshd_entdb_ol7.erb'
    if region_emagent[0] == 'prod'
      default['source_sshd'] = 'sshd_prod_ol7.erb'
      default['source_ssh'] = 'ssh_ol7.erb'
      default['source_hostsec_sshd'] = 'sshd_hostsec_ol7.erb'
      default['source_hostsec_ssh'] = 'ssh_hostsec_ol7.erb'
    else
      default['source_sshd'] = 'sshd_ol7.erb'
      default['source_ssh'] = 'ssh_ol7.erb'
      default['source_hostsec_sshd'] = 'sshd_hostsec_ol7.erb'
      default['source_hostsec_ssh'] = 'ssh_hostsec_ol7.erb'
    end
  when 8
    if(File.exist?('/root/.bst'))
      default['source_sshd_ent'] = 'sshd_entbst_ol8.erb'
    elsif(File.exist?('/root/.bst-port'))
      default['source_sshd_ent'] = 'sshd_entbstprt_ol8.erb'
    elsif realmkey_info == 'oc2'
      default['source_sshd_ent'] = 'sshd_oc2_ol8.erb'
    else
      default['source_sshd_ent'] = 'sshd_ent_ol8.erb'
    end
    default['source_sshd_ent'] = 'sshd_ent_ol8.erb'
    default['source_sshd_entdb'] = 'sshd_entdb_ol8.erb'
    if region_emagent[0] == 'prod'
      default['source_sshd'] = 'sshd_prod_ol8.erb'
      default['source_ssh'] = 'ssh_ol8.erb'
      default['source_hostsec_sshd'] = 'sshd_hostsec_ol8.erb'
      default['source_hostsec_ssh'] = 'ssh_hostsec_ol8.erb'
    else
      default['source_sshd'] = 'sshd_ol8.erb'
      default['source_ssh'] = 'ssh_ol8.erb'
      default['source_hostsec_sshd'] = 'sshd_hostsec_ol8.erb'
      default['source_hostsec_ssh'] = 'ssh_hostsec_ol8.erb'
    end
  when 9
    if(File.exist?('/root/.bst'))
      default['source_sshd_ent'] = 'sshd_entbst_ol9.erb'
    else
      default['source_sshd_ent'] = 'sshd_ent_ol9.erb'
    end
    default['source_sshd_entdb'] = 'sshd_entdb_ol9.erb'
    if region_emagent[0] == 'prod'
      default['source_sshd'] = 'sshd_prod_ol9.erb'
      default['source_ssh'] = 'ssh_ol9.erb'
      default['source_hostsec_sshd'] = 'sshd_hostsec_ol9.erb'
      default['source_hostsec_ssh'] = 'ssh_hostsec_ol9.erb'
    else
      default['source_sshd'] = 'sshd_ol9.erb'
      default['source_ssh'] = 'ssh_ol9.erb'
      default['source_hostsec_sshd'] = 'sshd_hostsec_ol9.erb'
      default['source_hostsec_ssh'] = 'ssh_hostsec_ol9.erb'
    end
  end
elsif node['platform'] == 'ubuntu'
  case node['platform_version'].to_i
  when 18,20
    default['source_sshd'] = 'sshd_ubuntu18.erb'
    default['source_ssh'] = 'ssh_ubuntu18.erb'
  when 22
    default['source_sshd'] = 'sshd_ubuntu22.erb'
    default['source_ssh'] = 'ssh_ubuntu22.erb'
  end
elsif node['platform'] == 'debian'
  case node['platform_version'].to_i
  when 10
    default['source_sshd'] = 'sshd_debian10.erb'
    default['source_ssh'] = 'ssh_debian10.erb'
  when 11
    default['source_sshd'] = 'sshd_debian11.erb'
    default['source_ssh'] = 'ssh_debian11.erb'
  end
else
  default['source_sshd'] = 'Unknown'
end
