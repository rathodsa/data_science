# configure_enable_ssh CHANGELOG

This file is used to list changes made in each version of the configure_enable_ssh cookbook.

## 0.1.0
- [your_name] - Initial release of configure_enable_ssh

## 0.1.1
- [your_name] - Included Ubuntu 18 for  configure_enable_ssh


- - -
Check the [Markdown Syntax Guide](http://daringfireball.net/projects/markdown/syntax) for help with Markdown.

The [Github Flavored Markdown page](http://github.github.com/github-flavored-markdown/) describes the differences between markdown on github and standard markdown.
