#
# Cookbook Name:: disk_partition
# Recipe:: default
#
# Copyright 2021, ORACLE
# Author:: naga.sai.vosetti@oracle.com
# All rights reserved - Do Not Redistribute
#
##################################
## Global Variables declaration ##
##################################
#################################################
## Installing & updating disk_partition on Oracle Linux ##
#################################################

if node['platform'] == 'oracle'
  cookbook_file "/tmp/partition.sh" do
    source 'partition.sh'
    owner 'root'
    group 'root'
    mode '0755'
    action :create
  end
  execute 'running repo.sh to create repo' do
    command '/tmp/partition.sh'
  end
else
  ruby_block 'OS is not supported' do
    block do
      Chef::Log.info('OS is not supported or configuration is not supported')
    end
  end
end
