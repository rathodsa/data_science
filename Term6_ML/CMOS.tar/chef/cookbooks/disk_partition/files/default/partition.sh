#!/bin/bash
        for ivol in `curl --connect-timeout 20 -H "Authorization: Bearer Oracle" http://169.254.169.254/opc/v2/instance/metadata/iscsivolumes/ --silent |grep volume_attachment |cut -d'"' -f 2`; do
            ipaddr=`curl --connect-timeout 20 -H "Authorization: Bearer Oracle" http://169.254.169.254/opc/v2/instance/metadata/iscsivolumes/$ivol/ipv4 --silent`
            port=`curl --connect-timeout 20 -H "Authorization: Bearer Oracle" http://169.254.169.254/opc/v2/instance/metadata/iscsivolumes/$ivol/port --silent`
            iqn=`curl --connect-timeout 20 -H "Authorization: Bearer Oracle" http://169.254.169.254/opc/v2/instance/metadata/iscsivolumes/$ivol/iqn --silent`
            iscsiadm -m node -o new -T ${iqn} -p ${ipaddr}:${port}
            iscsiadm -m node -o update -T ${iqn} -n node.startup -v automatic
            iscsiadm -m node -T ${iqn} -p ${ipaddr}:${port} -l
        done
	#Check whether sdb is mounted on the server
	os_version=$(cat /etc/oracle-release |tr -d '[a-z][A-Z]" "'|awk -F "." '{print $1}')
	disk2=$(cat /proc/partitions |grep sdb| tail -1|cut -c 26-28)
	disk1=$(cat /proc/partitions |grep sda| tail -1|cut -c 26-28)
        disks=""
        if [ -z "${disk1}" ]
        then
           echo "sda is not attached"
        else
	  mount |grep sda
	  if [ $? -eq 0 ]
	  then
	        echo "/dev/sda already mounted"
          else
                pvs=`pvs | grep sdb`
                if [ $? -eq 0 ]
                then
                      echo "/dev/sdb already mounted"
                else
                      disks="sda"
                fi
          fi
        fi

        if [ -z "${disk2}" ]
        then
           echo "sdb is not attached"
        else
          mount |grep sdb
          if [ $? -eq 0 ]
          then
                echo "/dev/sdb already mounted"
          else
                pvs=`pvs | grep sdb`
                if [ $? -eq 0 ]
                then
		      echo "/dev/sdb already mounted"     
                else
                     disks="sdb"
                fi
          fi
        fi

        if [ -z "${disks}" ]
        then
		echo "No Free disks for /u01"
        else
                parted -s /dev/${disks} mklabel gpt mkpart LVM 0% 100%
                pvcreate /dev/${disks}1
                vgcreate vg_data /dev/${disks}1
                lvcreate -n u01 -l 100%FREE vg_data
                mkfs.ext4 /dev/vg_data/u01
                echo $(blkid | sort | awk '/vg_data-u01/{print $2" /u01 ext4 defaults,noatime,_netdev,nofail 0 2"}') >> /etc/fstab
                mkdir /u01
                chown opc:opc /u01
                mount /u01
	fi
