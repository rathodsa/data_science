require 'chef/handler/json_file'
report_handlers [ Chef::Handler::JsonFile.new(:source=> "/var/chef/cookbooks/General_Lib_Functions/libraries/json_file.rb",:path => "/var/chef/reports") ]
exception_handlers [ Chef::Handler::JsonFile.new(:source=> "/var/chef/cookbooks/General_Lib_Functions/libraries/json_file.rb",:path => "/var/chef/reports") ]
cookbook_path '/var/chef/cookbooks'
role_path '/var/chef/roles'
encrypted_data_bag_secret '/etc/chef/encrypted_data_bag_secret'
infra_envconfig='FARMDEV'
infra_rolename='FARM_FMW'
infra_confname='FARM_FMW'
